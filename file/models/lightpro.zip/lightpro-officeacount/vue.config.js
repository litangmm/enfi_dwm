module.exports = {
  publicPath: process.env.NODE_ENV === 'production' ? '/wechat-public-question/': '/',
  productionSourceMap: false,
}
