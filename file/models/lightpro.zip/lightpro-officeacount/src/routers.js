const RegisterStart = () => import(/* webpackChunkName: 'Register' */  "@/views/Register/RegisterStart");
const RegisterSuccess = () => import(/* webpackChunkName: 'Register' */  "@/views/Register/RegisterSuccess");
const Register = () => import(/* webpackChunkName: 'Register' */  "@/layouts/Register");
const RegisterInput = () => import(/* webpackChunkName: 'Register' */  "@/views/Register/RegisterInput");
const RegisterCoupon = () => import(/* webpackChunkName: 'Register' */  "@/views/Register/RegisterCoupon");

const QuestionAire = () => import(/* webpackChunkName: 'QuestionAire' */  "@/layouts/QuestionAire");
const QuestionAireStart = () => import(/* webpackChunkName: 'QuestionAire' */  "@/views/QuestionAire/QuestionAireStart");
const QuestionAireQa = () => import(/* webpackChunkName: 'QuestionAire' */  "@/views/QuestionAire/QuestionAireQa");
const QuestionAireLocation = () => import(/* webpackChunkName: 'QuestionAire' */  "@/views/QuestionAire/QuestionAireLocation");
const QuestionAireSuccess = () => import(/* webpackChunkName: 'QuestionAire' */ "@/views/QuestionAire/QuestionAireSuccess");

const NotFound = () => import(/* webpackChunkName: 'Main' */  "@/layouts/NotFound");
const Auth = () => import(/* webpackChunkName: 'Main' */  "@/views/Auth");

const BMI = () => import(/* webpackChunkName: 'Bmi' */  "@/layouts/BMI");
const BMIInput = () => import(/* webpackChunkName: 'Bmi' */  "@/views/BMI/BMIInput");
const BMIResult = () => import(/* webpackChunkName: 'Bmi' */  "@/views/BMI/BMIResult");

const routers = [
    {
        path: '/',
        redirect: '/auth',
    },
    {
        name: 'auth',
        path: '/auth',
        component: Auth,
        meta: {
            title: '授权'+''
        },
    },
    {
        name: 'register',
        path: '/register',
        component: Register,
        children: [
            // {
            //     path: '',
            //     redirect: 'start',
            // },
            {
                path: 'start',
                component: RegisterStart,
                meta: {
                    title: '成为会员'+'',
                    keepAlive: true,
                },
            },
            {
                path: 'input',
                component: RegisterInput,
                meta: {
                    title: '成为会员'+''
                },
            },
            {
                path: 'success',
                component: RegisterSuccess,
                meta: {
                    title: '成为会员'+''
                },
            },
            {
                path: 'coupon',
                component: RegisterCoupon,
                meta: {
                    title: '优惠券'+''
                },
            },
        ],
    },
    {
        name: 'questionAire',
        path: '/questionAire',
        component: QuestionAire,
        children: [
            // {
            //     path: '',
            //     redirect: 'qa',
            // },
            {
                path: 'start',
                component: QuestionAireStart,
                meta: {
                    title: '体验官申请-调查问卷'+''
                },
            },
            {
                path: 'qa',
                component: QuestionAireQa,
                meta: {
                    title: '体验官申请-调查问卷'+''
                },
            },
            {
                path: 'location',
                component: QuestionAireLocation,
                meta: {
                    title: '体验官申请-收货信息'+''
                },
            },
            {
                path: 'success',
                component: QuestionAireSuccess,
                meta: {
                    title: '申请成功'+''
                },
            },
        ],
    },
    {
        name: 'bmi',
        path: '/bmi',
        component: BMI,

        children: [
            // {
            //     path: '',
            //     redirect: 'input',
            // },
            {
                path: 'input',
                component: BMIInput,
                meta: {
                    title: 'BMI&BMR计算'+'',
                    keepAlive: true,
                },
            },
            {
                path: 'result',
                name: 'bmiresult',
                component: BMIResult,
                meta: {
                    title: 'BMI&BMR计算'+'',
                    // keepAlive: true,
                },
            },
        ],
    },
    {
        path: '*',
        component: NotFound,
        meta: {
            title: '迷路了'
        },
    },
]

export default routers
