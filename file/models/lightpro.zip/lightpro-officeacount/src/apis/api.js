import {get, post, put} from '@/utils/axios'

const getPrice = p => get("/light-pro/wx/coupon/price",p)

//    注册会员模块
//    1. 是否为会员
const memberCheck = p => get("/light-pro/wx/user/check",p)
//    2. 保存手机并获取验证码
const checkPhone = p => post("/light-pro/wx/user/verification",p)
//    3. 注册
const registerPost = p => post("/light-pro/wx/user/register",p)

//

//    体验官
//    1. 是否是体验管
const officeCheck = p => get("/light-pro/wx/officer/check",p)
//    2. 问卷
//      2.1 获取问卷
const qaGet = p => get("/light-pro/wx/question/questionnaire",p)
//      2.2 答题
const answerSave = p => post("/light-pro/wx/test/answer",p)
//    4. 通过公众号会员修改信息接口保存收货信息
const addressSave = p => put("/light-pro/wx/user/update",p)
//    5. 申请体验官
const officeApply = p => post("/light-pro/wx/officer/apply",p)
//
//    BMI计算
//    1. 保存健康指数？
const bmiSave = p => post("/light-pro/wx/user/info/save",p)
//
//    优惠券
//    1. 获取优惠券
const couponGive = p => get("/light-pro/wx/coupon/give", p)
//    2. 是否可跳
const couponSave = p => post("/light-pro/wx/coupon/info/give", p)
//    3. 跳转
const api = {
    memberCheck,
    checkPhone,
    registerPost,
    officeCheck,
    qaGet,
    answerSave,
    addressSave,
    officeApply,
    bmiSave,
    couponGive,
    couponSave,
    getPrice,
}
export default api

// // 将 api 引入到 main.js 中
// Vue.prototype.$api = api
//
// // 这样页面中使用
// this.$api.reqLogin().then(res => {
//     console.log(res)
// })
