export default {
    "result": true,
    "code": 200,
    "data": [{
        "question": {"id": 1, "subject": "您是否使用过其他代餐产品？（可多选）", "type": 2, "sort": 1, "status": null},
        "answerList": [{"id": 1, "questionId": 1, "option": "A", "answer": "S-meal", "sort": null}, {
            "id": 2,
            "questionId": 1,
            "option": "B",
            "answer": "Wonderlab",
            "sort": null
        }, {"id": 3, "questionId": 1, "option": "C", "answer": "Fit8", "sort": null}, {
            "id": 4,
            "questionId": 1,
            "option": "D",
            "answer": "未使用",
            "sort": null
        }, {"id": 5, "questionId": 1, "option": "E", "answer": "其他", "sort": null}]
    }, {
        "question": {"id": 2, "subject": "您使用代餐产品的频率是?", "type": 1, "sort": 2, "status": null},
        "answerList": [{"id": 6, "questionId": 2, "option": "A", "answer": "每日1次", "sort": null}, {
            "id": 7,
            "questionId": 2,
            "option": "B",
            "answer": "每日2次",
            "sort": null
        }, {"id": 8, "questionId": 2, "option": "C", "answer": "每日3次", "sort": null}, {
            "id": 9,
            "questionId": 2,
            "option": "D",
            "answer": "未使用",
            "sort": null
        }, {"id": 10, "questionId": 2, "option": "E", "answer": "其他", "sort": null}]
    }, {
        "question": {"id": 3, "subject": "您使用代餐产品的原因是？（可多选）", "type": 2, "sort": 3, "status": null},
        "answerList": [{"id": 11, "questionId": 3, "option": "A", "answer": "减脂", "sort": null}, {
            "id": 12,
            "questionId": 3,
            "option": "B",
            "answer": "保持身材",
            "sort": null
        }, {"id": 13, "questionId": 3, "option": "C", "answer": "快速代餐", "sort": null}, {
            "id": 14,
            "questionId": 3,
            "option": "D",
            "answer": "新鲜，想尝试",
            "sort": null
        }, {"id": 15, "questionId": 3, "option": "E", "answer": "其他", "sort": null}]
    }, {
        "question": {"id": 4, "subject": "您每周健身的频率是？", "type": 1, "sort": 4, "status": null},
        "answerList": [{"id": 16, "questionId": 4, "option": "A", "answer": "1~2次", "sort": null}, {
            "id": 17,
            "questionId": 4,
            "option": "B",
            "answer": "3~5次",
            "sort": null
        }, {"id": 18, "questionId": 4, "option": "C", "answer": "6~7次", "sort": null}, {
            "id": 19,
            "questionId": 4,
            "option": "D",
            "answer": "不健身",
            "sort": null
        }, {"id": 20, "questionId": 4, "option": "E", "answer": "其他", "sort": null}]
    }, {
        "question": {"id": 5, "subject": "您成为轻补会员的动机是？（多选）", "type": 2, "sort": 5, "status": null},
        "answerList": [{"id": 21, "questionId": 5, "option": "A", "answer": "品牌理念", "sort": null}, {
            "id": 22,
            "questionId": 5,
            "option": "B",
            "answer": "营养咨询",
            "sort": null
        }, {"id": 23, "questionId": 5, "option": "C", "answer": "享受优惠", "sort": null}, {
            "id": 24,
            "questionId": 5,
            "option": "D",
            "answer": "其他",
            "sort": null
        }]
    }, {
        "question": {"id": 6, "subject": "您是如何知道轻补LightPro的？（可多选）", "type": 2, "sort": 6, "status": null},
        "answerList": [{"id": 25, "questionId": 6, "option": "A", "answer": "电商平台", "sort": null}, {
            "id": 26,
            "questionId": 6,
            "option": "B",
            "answer": "直播平台",
            "sort": null
        }, {"id": 27, "questionId": 6, "option": "C", "answer": "户外广告", "sort": null}, {
            "id": 28,
            "questionId": 6,
            "option": "D",
            "answer": "线下活动",
            "sort": null
        }, {"id": 29, "questionId": 6, "option": "E", "answer": "亲友介绍", "sort": null}, {
            "id": 30,
            "questionId": 6,
            "option": "F",
            "answer": "自行搜索",
            "sort": null
        }, {"id": 31, "questionId": 6, "option": "G", "answer": "其他", "sort": null}]
    }, {
        "question": {"id": 7, "subject": "您是否愿意向周围的亲友、同事推荐我们的产品？", "type": 1, "sort": 7, "status": null},
        "answerList": [{"id": 32, "questionId": 7, "option": "A", "answer": "愿意", "sort": null}, {
            "id": 33,
            "questionId": 7,
            "option": "B",
            "answer": "一般",
            "sort": null
        }, {"id": 34, "questionId": 7, "option": "C", "answer": "不愿意", "sort": null}]
    }, {
        "question": {"id": 8, "subject": "请写下您相对我们说的话，越用心的文字，越有可能被我们选中。", "type": 4, "sort": 8, "status": null},
        "answerList": [{"id": null, "questionId": 8, "option": null, "answer": null, "sort": null}]
    }],
    "message": "ok"
}
