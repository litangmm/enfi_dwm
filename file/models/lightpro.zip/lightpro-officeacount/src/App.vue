<template>
  <div id="app">
    <keep-alive>
      <router-view v-if="$route.meta.keepAlive">
        <!-- 这里是会被缓存的视图组件，比如 Home！ -->
      </router-view>
    </keep-alive>

    <router-view v-if="!$route.meta.keepAlive">
      <!-- 这里是不被缓存的视图组件，比如 Edit！ -->
    </router-view>

<!--    <router-view></router-view>-->
  </div>
</template>

<script>
import './init.css'

export default {
  name: 'App',
  components: {},
  created() {

  },
  watch: {
    '$route' () {
      const token = localStorage.getItem('token')
      if (this.$route.path === '/auth' || this.$route.path === '/') {
          return
      }
      if (token === '' || !token) {
        localStorage.setItem('backPath', this.$route.path)
        this.$router.push({path: `/auth`})
      }
    }
  },
}
</script>

<style>
#app {
  font-family: -apple-system, BlinkMacSystemFont, 'Helvetica Neue', Helvetica, Segoe UI, Arial, Roboto, 'PingFang SC', 'Hiragino Sans GB', 'Microsoft Yahei', sans-serif;
//font-family: Avenir, Helvetica, Arial, sans-serif; //-webkit-font-smoothing: antialiased; //-moz-osx-font-smoothing: grayscale; //text-align: center; //color: #2c3e50; //margin-top: 60px;
}
</style>
