<template>
  <div class="resultC">
    <div class="text">
      <span class="name">{{ name }}</span>
      <p class="numanddw">
        <span class="num">{{ num }}</span>
        <span class="dw">{{ text1 }}</span>
      </p>
      <p class="res" @click="$emit('help','')">
        <span>{{ text2 }}</span>
        <van-icon v-if="name==='BMI 身体质量指数'" size="18" style="position: absolute;top: 50%;transform: translateY(-50%)" name="question-o"/>
      </p>
    </div>
    <span v-if="type==1" class="bottom1">
    </span>
    <span v-if="type==1" class="bottom2">
    </span>
    <span v-if="type==2" class="bottom3">
    </span>
    <span v-if="type==2" class="bottom4">
    </span>
  </div>
</template>

<script>
export default {
  props: {
    name: {
      type: String
    },
    num: {
      type: String
    },
    text1: {
      type: String
    },
    text2: {
      type: String
    },
    type: {
      type: String
    },
  }
}
</script>

<style scoped lang="less">
.resultC {
  width: 100%;
  height: 170px;
  background: #ffffff;
  box-shadow: 0px 49px 25px -30px #dcdcdc;
  display: flex;
  flex-direction: column;
  margin: 10px 20px;

  .text {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
    text-align: center;

    .name {
      margin: 10px 0 0;
      font-size: 22px;
      font-weight: 600;
      text-align: center;
      color: #10202f;
      line-height: 30px;
    }

    .numanddw {
      width: 100%;
      position: relative;

      .num {
        margin: 12px 0;
        font-size: 72px;
        text-align: center;
        color: #10202f;
        line-height: 84px;
        font-weight: 800;
      }

      .dw {
        font-size: 12px;
        font-weight: 600;
        text-align: center;
        color: #10202f;
        line-height: 17px;
        position: absolute;
        bottom: 12px;
      }
    }


    .res {
      position: relative;
      font-size: 16px;
      font-weight: 600;
      text-align: center;
      color: #a5a5a5;
      line-height: 22px;
    }
  }


  .bottom1 {
    width: 100%;
    height: 12px;
    background: #7571FF;
    bottom: 0;
  }

  .bottom2 {
    width: 100%;
    height: 3px;
    background: #3835A4;
  }

  .bottom3 {
    width: 100%;
    height: 12px;
    background: #ff9571;
  }

  .bottom4 {
    width: 100%;

    height: 3px;
    background: #B16145;
  }
}
</style>
