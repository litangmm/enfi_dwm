<template>
  <div class="input_container">
    <div class="input_container_top" @click="showPicker = true">
        <p class="top1">{{value}}</p>
        <p class="top2">{{selectBottom}}</p>
    </div>
    <div class="input_container_bottom" :style="'background: '+ bottomColor">{{ bottomText }}</div>
    <van-popup v-model="showPicker" position="bottom" safe-area-inset-bottom>
      <van-picker
          show-toolbar
          :columns="columns"
          @confirm="onConfirm"
          @cancel="showPicker = false"
          :default-index="defalut_index - 1"
      />
    </van-popup>
  </div>

</template>

<script>
export default {
  props: {
    'type': {
      type: String
    },
  },
  data() {
    return {
      bottomText: '',
      value: '',
      selectBottom: '',
      showPicker: false,
      defalut_index: '1',
    }
  },
  methods:{
    onConfirm(value) {
      this.value = value;
      this.showPicker = false
      this.$emit("valueChange", value)
    },
    createIntArray(start,end){
      let res = []
      while (start<end){
        res.push(start++)
      }
      return res
    },
  },
  created() {
    if (this.type === '1') {
      this.bottomText = '性别'
      this.bottomColor = '#D2F0F6'
      this.selectBottom = ''
      this.value = '男'
      this.columns = ['男','女']
    } else if (this.type === '2') {
      this.bottomText = '年龄'
      this.bottomColor = '#DAF6D2'
      this.selectBottom = 'years old'
      this.value = '21'
      this.columns = this.createIntArray(1,99)
      this.defalut_index = 21
    } else if (this.type === '3') {
      this.bottomText = '身高'
      this.bottomColor = '#F6D2D2'
      this.selectBottom = 'cm'
      this.value = '180'
      this.columns = this.createIntArray(1,200)
      this.defalut_index = 180
    } else {
      this.bottomText = '体重'
      this.bottomColor = '#ECD2F6'
      this.selectBottom = 'kg'
      this.value = '70'
      this.columns = this.createIntArray(1,199)
      this.defalut_index = 70
    }
  }
}
</script>

<style scoped lang="less">
.input_container{
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background: #ffffff;
  border-radius: 8px;
  box-shadow: -3px 3px 6px 0px #ececee;
  font-weight: 400;
  text-align: center;
  margin: 10px 0;

  .input_container_top{
    width: 100%;
    padding: 5px 0;

    .top1{
      font-size: 30px;
      color: #8c989d;
    }
    .top2{
      font-size: 12px;
      color: #c9caca;
    }
  }
  .input_container_bottom{
    width: 100%;
    padding: 2px 0;
    font-size: 16px;
    color: #424141;
    line-height: 22px;
  }
}
</style>
