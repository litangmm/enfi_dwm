import Vue from 'vue'
import App from './App.vue'
import api from "@/apis/api";
import {
    Button,
    Checkbox,
    Col,
    Row,
    Form,
    Area,
    Popup,
    Field,
    DatetimePicker,
    Picker,
    // Pagination,
    Progress,
    CheckboxGroup,
    Divider,
    Cell,
    CellGroup,
    Icon,
    Radio,
    RadioGroup,
    Dialog,
    Toast,
    // Stepper,
    // NumberKeyboard,
    Loading,
    Overlay,
} from "vant";



import VueRouter from 'vue-router'
import routers from "@/routers";


Vue.prototype.$api = api

Vue.use(VueRouter)
Vue.config.productionTip = false
Vue.use(Button);
Vue.use(Checkbox);
Vue.use(Col);
Vue.use(Row);
Vue.use(Form);
Vue.use(Area);
Vue.use(Popup);
Vue.use(Field);
Vue.use(DatetimePicker);
Vue.use(Picker);
// Vue.use(Pagination);
Vue.use(Progress);
Vue.use(Checkbox);
Vue.use(CheckboxGroup);
Vue.use(Divider);
Vue.use(Toast);
Vue.use(Cell);
Vue.use(CellGroup);
Vue.use(Icon);
Vue.use(Radio);
Vue.use(RadioGroup);
Vue.use(Dialog);
// Vue.use(Stepper);
// Vue.use(NumberKeyboard);
Vue.use(Loading);
Vue.use(Overlay);



const router = new VueRouter({
    mode: 'history',
    routes: routers,
    base: process.env.NODE_ENV === 'production' ? '/wechat-public-question/': '/',
    scrollBehavior(to, from, savedPosition) {
        if (savedPosition) {
            return savedPosition;
        } else {
            return {x: 0, y: 0}
        }
    },
})

router.beforeEach((to, from, next) => {//beforeEach是router的钩子函数，在进入路由前执行
    if (to.meta.title) {//判断是否有标题
        console.log(to.meta.title)
        document.title = to.meta.title
    }
    next()
})

new Vue({
    render: h => h(App),
    router,
}).$mount('#app')
