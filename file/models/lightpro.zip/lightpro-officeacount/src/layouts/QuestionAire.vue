<template>
  <router-view></router-view>
</template>

<script>
export default {
name: "QuestionAire"
}
</script>

<style scoped>

</style>
