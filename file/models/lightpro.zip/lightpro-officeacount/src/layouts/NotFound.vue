<template>
<div>
  page not found
</div>
</template>

<script>
export default {
name: "NotFount"
}
</script>

<style scoped>

</style>
