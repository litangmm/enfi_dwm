<template>
  <div class="inputContainer">
    <div class="title">
      <span>BMI&BMR Calculator</span>
    </div>
    <ResultC type="1" name="BMI 身体质量指数" :num="bmiNum" :text2="bmiText" text1="" @help="showOverlay = true"></ResultC>
    <ResultC type="2" name="BMR 基础代谢率" :num="bmrNum" text2="" text1="千卡/天"></ResultC>
    <van-button type="info" class="submit van-ellipsis"
                color="linear-gradient(#55D420, #65B345)"
                @click="$router.go(-1)"
    >
      重新计算
    </van-button>

    <transition name="bounce">
      <div v-show="!showOverlay" style="position: fixed;bottom: 35px;right: 35px;display: flex;flex-direction: column;justify-content: center;align-items: center">
        <van-icon name="point-gift" color="#58A44A" size="70" @click="showOverlay = true"/>
        <p style="font-size: 12px;color:#58A44A">咨询营养师</p>
      </div>
    </transition>


    <div v-if="bmio.length!==0" hidden>
      {{dialogResult}}
      {{ bmio.sex }}
      {{ bmio.age }}
      {{ bmio.height }}
      {{ bmio.weight }}
    </div>
    <van-overlay :show="showOverlay">
      <div class="wrapper" @click="showOverlay = false" @click.stop>
        <img class="block" src="@/assets/qrcode.jpg" alt="">
        <p>长按免费咨询营养师</p>
        <!--        <div class="block"/>-->
      </div>
    </van-overlay>
    <!--    <van-dialog v-model="showDialog" title="福利" message="您获得了免费服务\n咨询营养师了解更多!"-->
    <!--                show-cancel-button-->
    <!--                confirmButtonText="好"-->
    <!--                cancelButtonText="不需要"-->
    <!--                confirmButtonColor="#58A44A"-->
    <!--                cancelButtonColor="#000000"-->
    <!--                @confirm="onDialogConfirm"-->
    <!--                @cancel="onDialogCancel"-->
    <!--    >-->

    <!--    </van-dialog>-->
  </div>
</template>

<script>
import ResultC from "@/components/BMI/ResultC";

export default {
  props: {
    bmi: {
      type: Object,
    }
  },

  data() {
    return {
      bmiNum: 0,
      bmrNum: 0,
      bmiText: '',
      bmio: {},
      showToast: false,
      showOverlay: false,
      showDialog: false,
      routerNext: {},
      dialogResult: -1,
    }
  },
  components: {
    ResultC,
  },
  beforeRouteLeave: async function (to, from, next) {
    if (!this.showOverlay&&this.dialogResult!=1) {
      this.$dialog.confirm({
        title: `福利`,
        message: `获得"免费咨询营养师"服务！`,
        confirmButtonText: `确认`,
        cancelButtonText: `取消`,
        closeOnPopstate: false,
        confirmButtonColor: '#58A44A',
        cancelButtonColor: '#000000',
      }).then(() => {
        next(false)

        this.dialogResult = 1
        this.showOverlay = true
        localStorage.setItem("dialogResult", 1)

      }).catch(() => {
        this.dialogResult = 0
        this.$toast("福利为您保存在计算结果右下角，记得去领取喔！")
        localStorage.setItem("dialogResult", 0)
        next()
      })
    }
    else {
      next()
    }
  },
  created() {
    this.dialogResult = localStorage.getItem('dialogResult') || -1
    console.log(this.bmi)
    console.log(this.$route.params.bmi)
    this.bmio = this.$route.params.bmi
    const {sex, age, height, weight} = this.$route.params.bmi
    let bmi = weight / (height * height) * 10000
    bmi = bmi.toFixed(1)
    // weight = bmi / 10000 * height * height
    // 18.5 / 10000 * height * height < std < 25 / 10000 * height * height
    let stdWeidhtMin = (18.5 / 10000 * height * height).toFixed(1)
    let stdWeidhtMax = (25 / 10000 * height * height).toFixed(1)
    let bmitext = '偏低'
    if (bmi < 18.5) {
      bmitext = `偏低（低${(stdWeidhtMin - weight).toFixed(1)} kg）`
    } else if (bmi < 25) {
      bmitext = '标准'
    } else if (bmi < 30) {
      bmitext = `偏胖（超${(weight - stdWeidhtMax).toFixed(1)} kg）`
    } else {
      bmitext = `肥胖（超${(weight - stdWeidhtMin).toFixed(1)} kg）`
    }
    let bmr = 10 * weight + 6.25 * height - 5 * age
    if (sex === 0) {
      bmr = 10 * weight + 6.25 * height - 5 * age + 5
    } else {
      bmr = 10 * weight + 6.25 * height - 5 * age - 161
    }
    bmr = bmr.toFixed(0)
    this.bmiText = bmitext
    this.bmrNum = bmr.toString()
    this.bmiNum = bmi.toString()
  },
  activated() {
    // console.log(this.bmi)
    // console.log(this.$route.params.bmi)
    // if (!this.$route.params.bmi) {
    //   return
    // }
    // this.bmio = this.$route.params.bmi
    // const {sex, age, height, weight} = this.$route.params.bmi
    // let bmi = weight / (height * height) * 10000
    // bmi = bmi.toFixed(1)
    // let bmitext = '偏低'
    // if (bmi < 18.5) {
    //   bmitext = '偏低'
    // } else if (bmi < 25) {
    //   bmitext = '标准'
    // } else if (bmi < 30) {
    //   bmitext = '超重'
    // } else {
    //   bmitext = '肥胖'
    // }
    // let bmr = 10 * weight + 6.25 * height - 5 * age
    // if (sex === 0) {
    //   bmr = 10 * weight + 6.25 * height - 5 * age + 5
    // } else {
    //   bmr = 10 * weight + 6.25 * height - 5 * age - 161
    // }
    // bmr = bmr.toFixed(0)
    // this.bmiText = bmitext
    // this.bmrNum = bmr.toString()
    // this.bmiNum = bmi.toString()
  },
  methods: {}

}
</script>

<style scoped lang="less">
.inputContainer {
  height: 100vh;
  width: 100vw;
  background: #f7f8fa;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 15px 15px env(safe-area-inset-bottom);

  .title {
    width: 100%;
    height: 30px;
    font-size: 22px;
    font-weight: 600;
    color: #10202f;
    line-height: 30px;
  }

  .submit {
    margin-top: 14px;
    width: 100%;
    border-radius: 10px;
    font-size: 18px;
    font-weight: 600;
    height: 48px;
  }

  .wrapper {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    flex-direction: column;
    color: white;
    font-size: 24px;

    .block {
      width: 300px;
      height: 300px;
      background-color: #fff;
    }

    p {
      margin: 2em 0;
    }

  }

}
.bounce-enter-active {
  animation: bounce-in .5s 0s 2;
}
.bounce-leave-active {
  animation: bounce-in .5s reverse;
}
@keyframes bounce-in {
  0% {
    transform: scale(0);
  }
  50% {
    transform: scale(1.5);
  }
  100% {
    transform: scale(1);
  }
}
</style>
