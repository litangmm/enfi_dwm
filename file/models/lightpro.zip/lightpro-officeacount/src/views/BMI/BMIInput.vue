<template>
  <!--  <div>-->
  <!--    <van-form @submit="onSubmit">-->
  <!--      <van-field label="性别" name="性别" input-align="right">-->
  <!--        <template #input>-->
  <!--          <van-stepper v-model="sex" input-width="40px" button-size="32px" integer min="1" max="2"/>-->
  <!--        </template>-->
  <!--      </van-field>-->
  <!--      <van-field label="年龄" name="年龄" input-align="right" >-->
  <!--        <template #input>-->
  <!--          <van-stepper v-model="age" input-width="40px" button-size="32px" integer min="1" max="150"/>-->
  <!--        </template>-->
  <!--      </van-field>-->
  <!--      <van-field label="体重" name="体重" input-align="right">-->
  <!--        <template #input>-->
  <!--          <van-stepper v-model="weight" input-width="40px" button-size="32px" integer min="5" max="300"/>-->
  <!--        </template>-->
  <!--      </van-field>-->
  <!--      <van-field label="身高" name="身高" input-align="right">-->
  <!--        <template #input>-->
  <!--          <van-stepper v-model="height" input-width="40px" button-size="32px" integer min="50" max="300"/>-->
  <!--        </template>-->
  <!--      </van-field>-->
  <!--    </van-form>-->
  <!--  </div>-->
  <div class="inputContainer">
    <div class="title">
      <span>BMI&BMR Calculator</span>
    </div>
    <InputC type="1" @valueChange="changeSex"></InputC>
    <InputC type="2" @valueChange="changeAge"></InputC>
    <InputC type="3" @valueChange="changeHt"></InputC>
    <InputC type="4" @valueChange="changeWt"></InputC>
    <van-button type="info" class="submit van-ellipsis"
                color="linear-gradient(#55D420, #65B345)"
                @click="submit"
    >
      提 交
    </van-button>
  </div>
</template>

<script>
import InputC from "@/components/BMI/InputC";

export default {
  name: "BMIInput",
  data() {
    return {
      sex: 0,
      age: 21,
      weight: 70,
      height: 180,
    }
  },
  components: {
    InputC,
  },
  created() {
    localStorage.setItem("dialogResult", -1)
    // const bmi = localStorage.getItem('bmi')
    // const {sex,age,weight,height} = bmi
    // if(sex&&age&&weight&&height){
    //   this.sex = bmi.sex
    //   this.age = bmi.age
    //   this.weight = bmi.weight
    //   this.height = bmi.height
    // }

  },
  methods: {
    changeSex(value) {
      this.sex = value === '男' ? 0 : 1
    },
    changeAge(value) {
      this.age = value
    },
    changeWt(value) {
      this.weight = value
    },
    changeHt(value) {
      this.height = value
    },
    submit() {
      const bmi = {
        openId: localStorage.getItem('token'),
        sex: this.sex,
        age: this.age,
        height: this.height,
        weight: this.weight,
      }
      localStorage.setItem('bmi',bmi)
      this.$api.bmiSave(bmi).then(res => {
        console.log(res)
      }).catch((err) => {
        console.log(err)
      }).finally(() => {
        this.$router.push({name: 'bmiresult', params: {bmi: bmi}})
      })
    }
  }
}
</script>

<style scoped lang="less">
.inputContainer {
  height: 100vh;
  width: 100vw;
  background: #f7f8fa;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 15px 15px env(safe-area-inset-bottom);

  .title {
    width: 100%;
    height: 30px;
    font-size: 22px;
    font-weight: 600;
    color: #10202f;
    line-height: 30px;
  }

  .submit {
    margin-top: 14px;
    width: 100%;
    border-radius: 10px;
    font-size: 18px;
    font-weight: 600;
    height: 48px;
  }

}
</style>
