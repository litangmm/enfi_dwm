<template>
  <div style="height: 100vh;width: 100vw;display: flex;justify-content: center;align-items: center;">
    <van-loading size="24px" v-if="!timeOut">加载中...</van-loading>
    <span v-if="timeOut">授权超时...</span>
  </div>
</template>

<script>
import {getUrlKey} from "@/utils/utils";

export default {
  props: ['token'],
  data() {
    return {
      backUrl: '',
      timeOut: false,
    }
  },
  created() {
    setTimeout(()=>{
      this.timeOut = true
    },10000)
    // console.log(this.$route.path)
    const token = getUrlKey("token")
    if (token) {
      localStorage.setItem('token', token);
      let backPath = localStorage.getItem('backPath')
      if(!backPath || backPath === '/'||backPath==='/auth'){
        backPath = '/register'
      }
      // console.log(`获取到token,准备跳转到${backPath}`)
      this.$toast.loading({
        message: '正在为您跳转...',
        forbidClick: true,
      });
      setTimeout(() => {
        this.$router.replace({path: backPath, query: {}})
      }, 618)
    } else {
      // console.log("去腾讯授权")
      setTimeout(() => {
        window.location.href = `http://www.lightpro.fit:9001/light-pro/weChat/public/auth/open?state=${window.location.href}`
      }, 1000)
    }
  },
  methods: {},
}
</script>

<style scoped>

</style>
