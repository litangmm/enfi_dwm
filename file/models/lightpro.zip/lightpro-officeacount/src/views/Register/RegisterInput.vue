<template>
  <div>
    <van-form class="register-form" @submit="onSubmit">
      <!--手机号-->
      <van-field
          v-model="phone"
          name="phone"
          label="您的手机号"
          placeholder="请输入"
          :rules="[{ required: true, message: '请正确填写手机号',pattern: /^[1](([3][0-9])|([4][5-9])|([5][0-3,5-9])|([6][5,6])|([7][0-8])|([8][0-9])|([9][1,8,9]))[0-9]{8}$/
 }]"
          clearable
          maxlength="11"
          type="tel"
      />

      <!-- 生日-->
      <van-field
          readonly
          clickable
          name="birthday"
          :value="birthday"
          label="您的生日"
          placeholder="请选择"
          @click="showBirthdayPicker = true"
          is-link
          :rules="[{ required: true, message: '请填写生日' }]"
      />

      <!--性别-->
      <van-field
          readonly
          clickable
          name="sex"
          :value="sex"
          label="您的性别"
          placeholder="请选择"
          @click="showSexPicker = true"
          is-link
          :rules="[{ required: true, message: '请选择性别' }]"
      />

      <!-- 姓名-->
      <van-field
          v-model="name"
          name="username"
          label="您的姓名"
          placeholder="请输入"
          :rules="[{ required: true, message: '请填写姓名' }]"
          maxlength="50"
          clearable
      />

      <!--      &lt;!&ndash;城市&ndash;&gt;-->
      <!--      <van-field-->
      <!--          readonly-->
      <!--          clickable-->
      <!--          name="area"-->
      <!--          :value="area"-->
      <!--          label="您所在的城市"-->
      <!--          placeholder="请选择"-->
      <!--          @click="showArea = true"-->
      <!--          is-link-->
      <!--          :rules="[{ required: true, message: '请选择所在城市' }]"-->
      <!--      />-->

      <!--验证码-->
      <van-field
          v-model="smscode"
          center
          clearable
          name="verificationCode"
          label="请输入验证码"
          type="digit"
          maxlength="4"
          :rules="[{ required: true, message: '请填写验证码' }]"
      >
        <template #button>
          <van-button :disabled="!smsAva"
                      @click="getSMSCode"
                      size="small" plain
                      color="#58A44A"
                      class="smsCode"
          >{{ smsText }}
          </van-button>
        </template>
      </van-field>

      <!--  提交按钮-->
      <van-button type="info" native-type="submit" class="submit van-ellipsis"
                  color="linear-gradient(#55D420, #65B345)">
        提 交
      </van-button>
      <span class="bottom-text">
        <van-icon :name="require('@/assets/safe.svg')"
                  size="14"/>
        <span>您的资料已经进行安全保护</span></span>
    </van-form>

    <van-popup v-model="showBirthdayPicker" position="bottom" safe-area-inset-bottom>
      <van-datetime-picker
          v-model="currentDate"
          type="date"
          :min-date="minDate"
          :max-date="maxDate"
          @confirm="onConfirmBirthday"
          @cancel="showBirthdayPicker = false"
      />
    </van-popup>
    <van-popup v-model="showSexPicker" position="bottom" safe-area-inset-bottom>
      <van-picker
          show-toolbar
          :columns="columns"
          @confirm="onConfirmSex"
          @cancel="showSexPicker = false"
      />
    </van-popup>
    <van-popup v-model="showArea" position="bottom" safe-area-inset-bottom>
      <van-area
          :area-list="areaList"
          @confirm="onConfirmArea"
          @cancel="showArea = false"
      />
    </van-popup>
  </div>
</template>

<script>
import area from "@/area";

export default {
  data() {
    return {
      token: '',
      phone: '',
      birthday: '',
      sex: '',
      name: '',
      area: '',
      smscode: '',
      smsAva: true,
      smsText: '获取验证码',
      showSexPicker: false,
      showBirthdayPicker: false,
      showArea: false,
      areaList: {}, // 数据格式见 Area 组件文档
      showPicker: false,
      currentDate: new Date(1980, 0, 1),
      minDate: new Date(1960, 0, 1),
      maxDate: new Date(),
      columns: ['男', '女'],
      price: '',
    };
  },
  beforeRouteUpdate(to, from, next) {
    console.log("beforeRouteUpdate")
    this.$dialog.confirm({
      title: `前方高能`,
      message: `价值80元的京东优惠券正在向您招手！`,
      confirmButtonText: `狠心离开`,
      cancelButtonText: `取消`,
    }).then(() => {
      next()
    }).catch(() => {
      next(false)
    })
  },
  beforeRouteLeave(to,from,next){
    console.log("beforeRouteLeave")
    console.log(to)
    if(to.path!=="/register/success"){
      this.$dialog.confirm({
        title: `真的要离开吗？`,
        message: `\n${this.price}京东优惠券正在向您招手！`,
        confirmButtonText: `留下`,
        cancelButtonText: `狠心离开`,
        closeOnPopstate: false,
        confirmButtonColor: '#58A44A',
        cancelButtonColor: '#000000',
      }).then(() => {
        next(false)
      }).catch(() => {
        next()
      })
    }else{
      next()
    }

    // if(to.path!=="/register/success"){'
    //   const answer = window.confirm('您真的要离开吗?\n完成注册可领取京东优惠券！')
    //   if (answer) {
    //     next()
    //   } else {
    //     next(false)
    //   }
    // }else{
    //   next()
    // }
  },
  created() {
    const token = localStorage.getItem("token")
    console.log(token)
    this.areaList = area;
    Date.prototype.Format = function (fmt) { //author: meizz
      var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "h+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
      };
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
      for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
      return fmt;
    }
    this.$api.getPrice().then(res=>{
      this.price = `价值${res}元的`
    })
  },
  methods: {
    getSMSCode() {
      if (!this.phone) {
        this.$toast('请先输入手机号')
        return
      }
      this.$api.checkPhone({
        'openId': localStorage.getItem('token'),
        'mobile': this.phone
      }).then(res => {
        // this.$toast.clear()
        console.log(res)
        this.smsAva = false
        this.$toast("验证码已发送")
        let last = 60
        this.smsText = `(${last--})重新获取`
        let interval = setInterval(() => {
          this.smsText = `(${last--})重新获取`
        }, 1000)
        setTimeout(() => {
          clearInterval(interval)
          this.smsAva = true
          this.smsText = '获取验证码'
        }, 60000)
      }).catch(err => {
        console.log(err)
      })

    },
    onConfirmSex(sex) {
      this.sex = sex;
      this.showSexPicker = false;
    },
    onConfirmArea(values) {
      this.area = values
          .filter((item) => !!item)
          .map((item) => item.name)
          .join('/');
      this.showArea = false;
    },
    onConfirmBirthday(time) {
      this.birthday = time.Format("yyyy-MM-dd");
      this.showBirthdayPicker = false;
    },
    onSubmit(values) {
      console.log('submit', values);
      values.sex = values.sex === '男' ? 0 : 1
      values.openId = localStorage.getItem('token')
      this.$api.registerPost(values)
          .then(res => {
            this.$toast.clear()
            console.log(res)
            this.$router.replace("success")
          })
          .catch(err => {
            this.$toast.clear()
            this.$toast(err.message)
            console.log(err)
          })
    },
  },
};
</script>

<style scoped lang="less">
.register-form {
  box-sizing: border-box;
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  font-size: 15px;
  padding: 0 0 env(safe-area-inset-bottom);

  .smsCode {
    width: 7em;
    padding: 0;
  }

  .submit {
    margin: auto 15px 0 15px;
    border-radius: 10px;
    font-size: 18px;
    font-weight: 600;
    height: 48px;
  }

  .bottom-text {
    color: #077FFF;
    font-size: 14px;
    font-weight: 600;
    margin: 9px auto;
    display: flex;
    justify-content: center;
  }
}
</style>
