<template>
  <div class="container">
    <img class="logo" src="../../assets/logo.svg" alt="">
    <span class="text">{{ text1 }}</span>
    <img class="qa" src="../../assets/qa.svg" alt="">
    <button class="button" @click="toRegister">开始注册</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      text1: '欢迎关注LightPro！注册成为会员，享受轻补健康生活。填写问卷，将有机会成为轻补体验官。'
    }
  },
  created() {
    this.checkRegister()
  },
  methods: {
    checkRegister(){
      this.$api.memberCheck({'openId': localStorage.getItem('token')})
          .then(res => {
            if(res===1){
              this.$toast("你已经是会员了")
              this.$router.push({path:'/register/success'})
            }
          })
          .catch(err => {
            this.$toast.clear()
            console.log(err)
          })
    },

    toRegister() {
      this.$api.memberCheck({'openId': localStorage.getItem('token')})
          .then(res => {
            if(res===1){
              this.$toast("你已经是会员了")
              this.$router.push({path:'/register/success'})
            }else{
              this.$router.push({path:"/register/input"})
            }
          })
          .catch(err => {
            this.$toast.clear()
            if(err.code===4001){
              this.$router.push({path:"/register/input"})
            }
          })
    }
  }

}
</script>

<style scoped lang="less">
.container {
  height: 100vh;
  width: 100vw;
  background: linear-gradient(315deg, #58a44a, #a7bc48);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  .logo {
    width: 190px;
    height: 52px;
    margin-bottom: 19px;
  }

  .text {
    width: 100%;
    padding: 0 30px;
    font-size: 15px;
    font-weight: 400;
    text-align: left;
    color: #ffffff;
    line-height: 21px;
  }

  .qa {
    height: 140px;
    width: 125px;
    margin: 67px 0;
  }

  .button {
    height: 40px;
    width: 240px;
    background: #ffffff;
    border-radius: 20px;
    color: #5FA648;
    font-size: 15px;
    font-weight: 600;
    border: none;
  }

}
</style>
