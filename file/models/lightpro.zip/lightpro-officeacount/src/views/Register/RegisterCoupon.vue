<template>
  <div class="coupon">
    <van-cell-group title="优惠券">
      <van-cell size="large" center is-link
                value="立即领取"
                v-for="coupon in couponList"
                :key="coupon.id"
                :title="coupon.name"
                @click="check(coupon.id, coupon.url)"
      />
    </van-cell-group>
    <!--    <img src="../../assets/7.png" alt="">-->
    <!--    <img src="../../assets/7.png" alt="">-->

  </div>
</template>

<script>
export default {
  data() {
    return {
      couponList: [
        // {
        //   "id": 1,
        //   "url": "https://www.baidu.com",
        //   "name": "测试-百度",
        //   "status": 1
        // },
        // {
        //   "id": 2,
        //   "url": "https://www.lightpro.fit",
        //   "name": "测试-轻补",
        //   "status": 1
        // }
      ],
    }
  },
  created() {
    this.getCoupon()
  },
  methods: {
    getCoupon() {
      this.$api.couponGive().then(res => {
        console.log(res)
        this.couponList = res
      }).catch(err => {
        console.log(err)
      })
    },
    check(id, url) {
      console.log(id, url)
      this.$api.couponSave({'couponId': id, 'openId': localStorage.getItem('token')}).then(res => {
        console.log(res)

        window.location.href = url

      }).catch(err => {
        console.log(err)
        if(err.code===4001){
          this.$router.push({path:"/register/start"})
        }
      })
    }
  }
}
</script>

<style scoped lang="less">
//.coupon{
//  width: 100vw;
//  height: 100vh;
//  display: flex;
//  flex-direction: column;
//  justify-content: flex-start;
//  align-items: center;
//  //padding: 20px 30px 0;
//  background: #f7f8fa;
//
//  img:nth-child(1){
//    margin-bottom: 15px;
//  }
//}
</style>
