<template>
  <div></div>
</template>

<script>
export default {
  created() {
    this.$router.push("/questionAire/qa")
  }
}
</script>

<style scoped>

</style>
