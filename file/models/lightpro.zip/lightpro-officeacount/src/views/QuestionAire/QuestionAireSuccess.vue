<template>
  <div class="container">
    <img class="logo" src="@/assets/success.svg" alt="">
    <div style="display: flex;flex-direction: column;justify-content: center;align-items: center">
      <p class="text1">申请成功</p>
      <p class="text2">欢迎加入轻补大家庭</p>
    </div>
    <p class="text3" style="word-break:normal;text-align: justify;">届时客服将会联系您，感谢您的申请。我们为您发放了<span style="color: #58A44A;text-decoration:underline;word-break : normal;" @click="$router.push({path:'/register/coupon'})">{{price}}京东优惠券（戳此）</span>，也可前往“公众号-会员服务-福利领取”页面领取使用。</p>
    <button class="button" @click="toBmi">测一测身体质量指数</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      price: ''
    }
  },
  created() {
    this.$api.getPrice().then(res=>{
      this.price = `${res}元`
    })
  },
  methods: {
    toBmi() {
      // 1. 检查token

      // 2. 检查token

      // 3. 跳转
      this.$router.push({path: '/bmi/input'})
    }
  }

}
</script>

<style scoped lang="less">
.container {
  height: 100vh;
  width: 100vw;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 0 0 env(safe-area-inset-bottom);

  .logo {

    width: 80px;
    height: 80px;
    margin-bottom: 19px;
    margin-top: 93px;
  }

  .text1 {
    height: 25px;
    font-size: 18px;
    font-weight: 500;
    text-align: left;
    color: #232323;
    line-height: 25px;
  }

  .text2 {
    height: 17px;
    font-size: 12px;
    font-weight: 500;
    text-align: left;
    color: #999999;
    line-height: 17px;
  }

  .text3 {
    width: 271px;
    height: 109px;
    font-size: 14px;
    font-weight: 500;
    text-align: justify;
    color: #666666;
    line-height: 20px;
    margin-top: 35px;
  }

  .qa {
    height: 140px;
    width: 125px;
    margin: 67px 0;
  }

  .button {
    width: 343px;
    height: 48px;
    color: #ffffff;
    border-radius: 13px;
    font-size: 18px;
    font-weight: 500;
    border: none;
    margin-top: auto;
    margin-bottom: 47px;
    background: linear-gradient(180deg, #55d420, #65b345);
  }

}
</style>
