<template>
  <div class="questionaire-container">
    <div class="title" style="padding: 15px 0">
      <span>{{ `${currentIndex + 1}、${currentQuestion.question.subject}` }}</span>
    </div>
    <div class="answer">
      <template v-if="currentQuestion.question.type===1">
        <van-radio-group v-model="result[currentIndex]">
          <template v-for="answer in currentQuestion.answerList">
            <van-radio
                checked-color="#58A44A"
                icon-size="24px"
                style="padding: 10px 0px;font-size: 15px;border-top: 1px solid #F1F1F1"
                :name="answer.id"
                :key="answer.id">
              {{ answer.option + "：" + answer.answer }}
            </van-radio>
            <van-field
                v-if="answer.answer==='其他'"
                v-model="message[currentIndex]"
                rows="1"
                type="textarea"
                placeholder="请输入"
                :key="answer.id+'text'"
                style="border: 1px solid #E3E3E3"
                maxlength="50"
                show-word-limit
            />
          </template>
        </van-radio-group>
      </template>

      <template v-else-if="currentQuestion.question.type===2">
        <van-checkbox-group v-model="result[currentIndex]">
          <template v-for="answer in items[currentIndex].answerList">
            <van-checkbox
                checked-color="#58A44A"
                icon-size="24px"
                style="padding: 10px 0px;font-size: 15px;border-top: 1px solid #F1F1F1"
                :name="answer.id"
                :key="answer.id">
              {{ answer.option + "：" + answer.answer }}
            </van-checkbox>
            <van-field
                v-if="answer.answer==='其他'"
                v-model="message[currentIndex]"
                rows="1"
                type="textarea"
                placeholder="请输入"
                :key="answer.id+'text'"
                style="border: 1px solid #E3E3E3"
                maxlength="50"
                show-word-limit
            />
          </template>
        </van-checkbox-group>
      </template>

      <template v-else-if="currentQuestion.question.type===4">
        <van-field
            v-model="message[currentIndex]"
            rows="10"
            type="textarea"
            placeholder="请输入"
            style="border: 1px solid #E3E3E3"

        />
      </template>
    </div>

    <div class="bar">
      <van-progress :percentage="(currentIndex + 1)/(items.length+1) *100"
                    :show-pivot="false"
                    color="linear-gradient(#55D420, #4F6C42)"
                    stroke-width="10"
      />
      <div class="bar-ctr">
        <span @click="pre" class="arrow" :style="currentIndex===1?'color:#8b8b8b':''">
          <van-icon name="arrow-left"/>
          <span>上一题</span>
        </span>
        <span class="current">
          {{ `${currentIndex + 1}/${items.length + 1}` }}
        </span>
        <span @click="after" class="arrow">
          <span>下一题</span>
          <van-icon name="arrow"/>
        </span>
      </div>
    </div>
  </div>
</template>

<script>
import qa from "@/qa";

let answerDictList = []

export default {
  data() {
    return {
      result: [],
      message: [],
      currentIndex: 0,
      items: [],
      currentQuestion: {},
      isLogin: false,
    };
  },
  beforeRouteLeave(to, from, next) {
    console.log("beforeRouteLeave")
    if (this.isLogin && to.path !== "/questionAire/location"){
      this.$dialog.confirm({
        title: `真的要离开吗？`,
        message: `\n成为轻补体验官可以免费获取轻补产品！`,
        confirmButtonText: `留下`,
        cancelButtonText: `狠心离开`,
        closeOnPopstate: false,
        confirmButtonColor: '#58A44A',
        cancelButtonColor: '#000000',
      }).then(() => {
        next(false)
      }).catch(() => {
        next()
      })
    }else{
      next()
    }

    // if (this.isLogin && to.path!=="/questionAire/location") {
    //   const answer = window.confirm('您真的要离开吗?\n成为轻补体验官可以免费获取轻补产品！')
    //   if (answer) {
    //     next()
    //   } else {
    //     next(false)
    //   }
    // } else {
    //   next()
    // }
  },
  beforeRouteUpdate(to,from,next){
    console.log("beforeRouteLeave")
    const answer = window.confirm('您真的要离开吗?\n完成注册可领取京东优惠券！')
    if (answer) {
      next()
    } else {
      next(false)
    }
  },
  watch: {
    currentIndex: function (val) {
      this.currentQuestion = this.items[val]
    },
  },
  created() {
    this.$api.memberCheck({'openId': localStorage.getItem('token')})
        .then(res => {
          console.log(1)
          if (res === 1) {
            // this.$toast(res)
            // this.$toast("你已经是会员了")
            console.log(res)
            this.isLogin = true
          } else {
            // this.$toast("请先注册")
            this.$router.replace({path: "/register/input"})
          }
        })
        .catch(err => {
          console.log(2)

          this.$toast.clear()
          console.log(err)
          // 3. 跳转
          this.$router.replace({path: "/register/input"})
        })

    this.items = qa.data
    this.currentQuestion = this.items[this.currentIndex]
    this.$api.qaGet().then(res => {
      console.log(res)
      this.items = res
      this.currentQuestion = this.items[this.currentIndex]
    }).catch(err => {
      console.log(err)
    })
  },
  methods: {
    pre() {
      if (this.currentIndex > 0) {
        this.saveAnswer()
        this.currentIndex -= 1
      } else {
        this.$toast("已经是第一题了")
      }
    },
    after() {
      this.saveAnswer()
      if (this.currentIndex < this.items.length - 1) {
        this.currentIndex += 1
      } else {
        this.submitAnswer()
        console.log(answerDictList)
      }
    },
    submitAnswer() {
      const emptyI = answerDictList.findIndex(item => {
        return item === undefined
      })
      console.log(emptyI)
      if (emptyI !== -1) {
        this.$dialog.confirm({
          title: '警告',
          message: `第${emptyI + 1}题没有选择答案\n点击确认去回答`,
        }).then(() => {
          this.currentIndex = emptyI
        })
        // this.$toast("已经是最后一题了")
      } else {
        const undefinedI = answerDictList.findIndex(item => {
          console.log(item)
          return item.answerList.findIndex(i => i["answerAdvise"] === undefined) !== -1
        })
        if (undefinedI !== -1) {
          this.$dialog.confirm({
            title: '警告',
            message: `第${undefinedI + 1}题选择了其他但是输入框为空\n点击确认去回答`,
          }).then(() => {
            this.currentIndex = undefinedI
          })
        } else {
          this.$dialog.confirm({
            title: '提示',
            message: `离体验官就差一步啦，快去完善收货地址`,
          }).then(() => {
            console.log(answerDictList)
            let jsonstring = JSON.stringify(answerDictList)
            this.$api.answerSave({'openId': localStorage.getItem('token'), 'answer': jsonstring}).then(res => {
              console.log(res)
              this.$router.replace("location")
            }).catch(err => {
              this.$toast.clear()
              if(err.code===4001){
                this.$router.push({path:"/register/input"})
              }
            })
          })
          // this.$dialog.confirm({
          //   title: '提示',
          //   message: `离体验馆就差一步啦，快去完善收货地址`,
          //   beforeClose: (action, done) => {
          //     if (action === 'confirm') {
          //       console.log(answerDictList)
          //       let jsonstring = JSON.stringify(answerDictList)
          //       this.$api.answerSave({'openId': localStorage.getItem('token'), 'answer': jsonstring}).then(res => {
          //         console.log(res)
          //         setTimeout(done, 1680);
          //         this.$router.replace("location")
          //       }).catch(err => {
          //         console.log(err)
          //         done();
          //       })
          //     } else {
          //       done();
          //     }
          //   },
          // }).then(() => {
          //
          // })
        }
      }
    },
    saveAnswer() {
      let answerDict = {
        question: {},
        answerList: [],
      }
      const {currentIndex, currentQuestion: {answerList, question}, message, result} = this
      answerDict.question = {
        questionId: question.id,
        questionSubject: question.subject,
      }
      if (question.type === 4) {
        answerDict.answerList = [{
          answerId: null,
          answerOption: null,
          answerAnswer: null,
          answerAdvise: message[currentIndex],
        }]
        answerDictList[currentIndex] = answerDict;
        return
      }

      let currentAnswer = result[currentIndex]
      if (!currentAnswer) return

      if (question.type === 1) {
        currentAnswer = [result[currentIndex]]
      }
      console.log(currentAnswer)


      currentAnswer.forEach((currentAnswerItem) => {
        const answer = answerList.find(item => item.id === currentAnswerItem)
        let needPush = {
          answerId: answer.id,
          answerOption: answer.option,
          answerAnswer: answer.answer,
          answerAdvise: null,
        }
        if (answer.answer === '其他') {
          needPush.answerAdvise = message[currentIndex]
        }
        answerDict.answerList.push(needPush)
      })
      console.log(answerDict)
      answerDictList[currentIndex] = answerDict;
    },
  }
}
</script>

<style lang="less" scoped>
.questionaire-container {
  box-sizing: border-box;
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  font-size: 15px;
  padding: 15px 15px env(safe-area-inset-bottom);

  .title {
    font-size: 18px;
  }

  .bar {
    margin-top: auto;
    margin-bottom: 22px;


    .bar-ctr {
      color: #58A44A;
      font-size: 15px;
      margin-top: 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;

      .current {
        margin: auto;
        color: #8b8b8b;
      }

      .arrow {
        display: flex;
        align-items: center;
      }
    }
  }
}
</style>
