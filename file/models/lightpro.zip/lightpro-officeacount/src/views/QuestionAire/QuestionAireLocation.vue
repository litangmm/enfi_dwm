<template>
  <div class="container">
    <div class="title" style="padding: 15px">
      <span>请留下您的收货信息，如果您被我们选中成为轻补体验官，我们将免费为您寄送最新产品，并欢迎您反馈体验意见。</span>
    </div>
    <van-cell-group title="收货信息">
      <van-form @submit="onSubmit" class="register-form">
        <!--手机号-->
        <van-field
            v-model="phone"
            name="phone"
            label="您的手机号"
            placeholder="请输入"
            :rules="[{ required: true, message: '请正确填写手机号',pattern: /^[1](([3][0-9])|([4][5-9])|([5][0-3,5-9])|([6][5,6])|([7][0-8])|([8][0-9])|([9][1,8,9]))[0-9]{8}$/
 }]"
            clearable
            maxlength="11"
            type="tel"
        />

        <!-- 姓名-->
        <van-field
            v-model="name"
            name="name"
            label="您的姓名"
            placeholder="请输入"
            :rules="[{ required: true, message: '请填写姓名' }]"
            clearable
            maxlength="50"
        />

        <!--城市-->
        <van-field
            readonly
            clickable
            name="area"
            :value="area"
            label="您所在的城市"
            placeholder="请选择"
            @click="showArea = true"
            is-link
        />
        <!-- 详细地址-->
        <van-field
            v-model="address"
            name="address"
            label="详细地址"
            placeholder="请输入"
            :rules="[{ required: true, message: '请填写详细地址' }]"
            clearable
            maxlength="100"
        />

        <div class="submit-container">
          <van-button type="info" native-type="submit" class="submit"
                      color="linear-gradient(#55D420, #65B345)">
            提 交
          </van-button>
        </div>
      </van-form>
      <van-popup v-model="showArea" position="bottom" safe-area-inset-bottom>
        <van-area
            :area-list="areaList"
            @confirm="onConfirmArea"
            @cancel="showArea = false"
        />
      </van-popup>
    </van-cell-group>

  </div>
</template>

<script>
import area from "@/area";

export default {
  name: "QuestionAireLocation",
  data() {
    return {
      phone: '',
      name: '',
      area: '',
      address: '',
      showArea: false,
      areaList: {}, // 数据格式见 Area 组件文档
      showPicker: false,
      currentDate: new Date(1980, 0, 1),
      minDate: new Date(1960, 0, 1),
      maxDate: new Date(),
      columns: ['男', '女'],
    };
  },
  beforeRouteLeave(to, from, next) {
    console.log("beforeRouteLeave")
    if (this.isLogin && to.path !== "/questionAire/success"){
      this.$dialog.confirm({
        title: `真的要离开吗？`,
        message: `\n成为轻补体验官可以免费获取轻补产品！`,
        confirmButtonText: `留下`,
        cancelButtonText: `狠心离开`,
        closeOnPopstate: false,
        confirmButtonColor: '#58A44A',
        cancelButtonColor: '#000000',
      }).then(() => {
        next(false)
      }).catch(() => {
        next()
      })
    }else{
      next()
    }
  },
  created() {
    this.areaList = area;
  },
  methods: {
    onConfirmArea(values) {
      this.area = values
          .filter((item) => !!item)
          .map((item) => item.name)
          .join('/');
      this.showArea = false;
    },
    onSubmit(values) {
      const [province,city,area] = values.area.split('/')
      this.$api.addressSave({
        province,city,area,
        telephone: values.phone,
        contact:values.name,
        address:values.address,
        openId: localStorage.getItem('token')
      }).then(res=>{
        console.log(res)
        this.$toast.success({
          message: '已提交收获信息'
        })
        this.$api.officeApply({
          openId: localStorage.getItem('token')
        }).then((res)=>{
          console.log(res)
          this.$toast.success({
            message: '已提交体验官申请'
          })
          setTimeout(()=>{
            this.$router.replace({path: '/questionAire/success'})
          },1168)
        }).catch(err => {
          if(err.code===4001){
            this.$toast.clear()
            this.$router.push({path:"/register/input"})
          }
        })
      }).catch(err => {
        if(err.code===4001){
          this.$toast.clear()
          this.$router.push({path:"/register/input"})
        }
      })
    },

  },
}
</script>

<style scoped lang="less">
.container {
  background: #F7F8FA;
  height: 100vh;
  width: 100vw;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  padding: 0 0 env(safe-area-inset-bottom);

  .title {
    font-size: 18px;
  }

  .submit-container {
    position: fixed;
    left: 15px;
    right: 15px;
    bottom: calc(47px + env(safe-area-inset-bottom));


    .submit {
      width: 100%;
      height: 48px;
      font-size: 18px;
      font-weight: 600;
      background: linear-gradient(180deg, #55d420, #65b345);
      border-radius: 13px;
    }
  }

}

</style>
