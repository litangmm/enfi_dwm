import axios from 'axios'
import {Toast} from "vant";
import qs from 'qs'

const baseURL = 'https://www.lightpro.fit'
axios.interceptors.request.use(
    config => {
        // 判断是否是提交文件，还是常规请求
        if (config.data instanceof FormData) {
            config.headers = {
                'Content-Type': 'multipart/form-data' // 此处格式自定义
            }
        } else {
            console.log(config.data)
            config.data = qs.stringify(config.data)
            config.headers = {
                'Content-Type': 'application/x-www-form-urlencoded;', // 此处格式自定义
            }
        }
        config.withCredentials = true
        config.timeout = 10000    // 超时时间
        return config
    },
    error => {
        return Promise.reject(error)
    }
)

// 添加响应拦截器
axios.interceptors.response.use(
    res => {
        Toast.clear()
        let data = res.data
        console.log(res)
        if (res.status !== 200) {
            if (data.failureReason === 4011 || data.failureReason === 4012) {
                console.log('需要重新登录')
            }
        } else {
            if (data.code === 200) {
                return data
            } else if(data.code === 4001){
                return Promise.reject(data)
            } else {
                Toast.fail({
                    message: data.message,
                })
                return Promise.reject(data)
            }
        }
    },
    error => {
        Toast.fail({
            message: '提示',
            duration: 2,
            description: '后台报错'
        })
        // 对响应错误做点什么
        return Promise.reject(error)
    }
)

export function get(url, params = {}) {
    Toast.loading({
        message: '网络连接中...',
        forbidClick: true,
        loadingType: 'spinner',
        duration: 0,
    })
    return new Promise((resolve, reject) => {
        url = baseURL + url
        axios.get(url, {params: params})
            .then(response => {
                console.log(response)
                resolve(response.data)
            })
            .catch(err => {
                reject(err)
            })
    })
}

/**
 * 封装post请求
 * @param url
 * @param data
 * @returns {Promise}
 */
export function post(url, data = {}) {
    Toast.loading({
        message: '网络连接中...',
        forbidClick: true,
        loadingType: 'spinner',
        duration: 0,
    })
    return new Promise((resolve, reject) => {
        url = baseURL + url
        axios.post(url, data).then(
            response => {
                console.log(response)
                resolve(response.data)
            },
            err => {
                reject(err)
            }
        )
    })
}

export function put(url, data = {}) {
    Toast.loading({
        message: '网络连接中...',
        forbidClick: true,
        loadingType: 'spinner',
        duration: 0,
    })
    return new Promise((resolve, reject) => {
        url = baseURL + url
        axios.put(url, data).then(
            response => {
                resolve(response.data)
            },
            err => {
                reject(err)
            }
        )
    })
}
