export default function (key) {
    return window.localStorage(key);
}
