const path = require('path')
const CompressionPlugin = require("compression-webpack-plugin")
const PrerenderSPAPlugin = require('prerender-spa-plugin')
const Renderer = PrerenderSPAPlugin.PuppeteerRenderer;

module.exports = {
    // 部署应用包时的基本 URL,用法和 webpack 本身的 output.publicPath 一致
    publicPath: '/',
    // 输出文件目录
    outputDir: './dist',
    assetsDir: 'public',
    // eslint-loader 是否在保存的时候检查
    lintOnSave: true,
    // 是否使用包含运行时编译器的 Vue 构建版本
    runtimeCompiler: false,
    // 生产环境是否生成 sourceMap 文件
    productionSourceMap: false,
    // 生成的 HTML 中的 <link rel="stylesheet"> 和 <script> 标签上启用 Subresource Integrity (SRI)
    integrity: false,
    // webpack相关配置
    chainWebpack: (config) => {
        config.resolve.alias
            .set('vue$', 'vue/dist/vue.esm.js')
            .set('@', path.resolve(__dirname, './src'))
    },
    configureWebpack: (config) => {
        if (process.env.NODE_ENV === 'production') {
            // 生产环境
            config.mode = 'production'
            return {
                plugins: [
                    new CompressionPlugin({
                        test: /\.js$|\.html$|\.css/, // 指定压缩文件
                        threshold: 10240, // 超过10kb的文件进行压缩
                        deleteOriginalAssets: false // 是否删除原文件
                    }),
                    new PrerenderSPAPlugin({
                        staticDir: path.join(__dirname, 'dist'),
                        routes: [
                            '/homepage',
                            '/minimeal',
                            '/terminal',
                            '/story/concept',
                            '/story/advocate',
                            '/story/contact',
                            '/story/desc',
                            '/story/join',
                        ],
                        renderer: new Renderer({
                            inject: {
                                foo: 'bar'
                            },
                            headless: false,
                            renderAfterDocumentEvent: 'render-event',
                        })
                    })
                ]
            }
        } else {
            // 开发环境
            config.mode = 'development'
        }
    },
    // 是否使用 thread-loader
    parallel: require('os').cpus().length > 1,
    // PWA 插件相关配置
    pwa: {},
    // webpack-dev-server 相关配置
    devServer: {
        // open: true,
        host: '0.0.0.0',
        port: 8080,
        https: false,
        hotOnly: false,
    },
    // 第三方插件配置
    pluginOptions: {}
}
