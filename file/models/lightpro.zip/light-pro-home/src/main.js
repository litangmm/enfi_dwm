import Vue from 'vue'
import VueRouter from 'vue-router'
import App from './App.vue'
import routers from "@/routers";
import VueI18n from "vue-i18n";
import VueMeta from 'vue-meta';
import en from './common/lang/en'
import zh from './common/lang/zh'


Vue.use(VueRouter)
Vue.use(VueI18n)
Vue.use(VueMeta, {
  keyName: 'head', // 定义组件中的数据对象
});

Vue.config.productionTip = false

const router = new VueRouter({
  mode: 'history',
  routes: routers,
  scrollBehavior(to,from,savedPosition){
    if(savedPosition){
      return savedPosition;
    }else{
      return {x:0,y:0}
    }
  },
})

router.beforeEach((to, from, next) => {
  // 统计代码
  if (to.path) window._hmt.push(['_trackPageview', '/#' + to.fullPath])
  next()
})

const i18n = new VueI18n({
  locale: localStorage.getItem('locale') ||'zh',
  messages: {
    'zh': { message: zh },
    'en': { message: en }
  }
})

new Vue({
  render: h => h(App),
  router,
  i18n,
  mounted() {
    document.dispatchEvent(new Event('render-event'))
  }
}).$mount('#app')
