<template>
  <div id="terminal" class="pageFlexColumnContainer">
    <TWhat></TWhat>
    <TNewAC></TNewAC>
    <TSolution></TSolution>
    <TLiquid></TLiquid>
    <TTech></TTech>
    <TCo></TCo>
    <PageEnd></PageEnd>
  </div>
</template>

<script>
import TWhat from "@/components/Terminal/TWhat";
import TNewAC from "@/components/Terminal/TNewAC";
import TCo from "@/components/Terminal/TCo";
import TTech from "@/components/Terminal/TTech";
import TSolution from "@/components/Terminal/TSolution";
import TLiquid from "@/components/Terminal/TLiquid";
import PageEnd from "@/components/PageEnd";

export default {
  name: "Terminal",
  components: {
    TWhat,
    TNewAC,
    TTech,
    TCo,
    TSolution,
    TLiquid,
    PageEnd,
  }
}
</script>

<style scoped>
#terminal {
  //display: flex;
  //flex-direction: column;
  //width: 100%;
}
</style>