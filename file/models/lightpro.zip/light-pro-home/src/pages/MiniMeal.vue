<template>
  <div id="minimeal" class="pageFlexColumnContainer">
    <Select></Select>
    <What></What>
    <Popular></Popular>
    <DescP></DescP>
    <Love></Love>
    <Tastes></Tastes>
    <PageEnd></PageEnd>
  </div>
</template>

<script>
import Select from "@/components/MiniMeal/Select";
import What from "@/components/MiniMeal/What";
import Popular from "@/components/MiniMeal/Popular";
import DescP from "@/components/MiniMeal/DescP";
import Love from "@/components/MiniMeal/Love";
import Tastes from "@/components/MiniMeal/Tastes";
import PageEnd from "@/components/PageEnd";


export default {
  name: "MiniMeal",
  components: {
    Select,What,Popular,DescP,Love,Tastes,PageEnd,
  }
}
</script>

<style scoped>
#minimeal{
  //display: flex;
  //flex-direction: column;
  //width: 100%;
}
</style>