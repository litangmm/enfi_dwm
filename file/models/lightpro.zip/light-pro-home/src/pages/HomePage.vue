<template>
  <div id="homepage" class="pageFlexColumnContainer">
    <Create></Create>
    <Milk></Milk>
    <Terminal></Terminal>
    <Friends></Friends>
    <PageEnd></PageEnd>
  </div>
</template>
<script>
import Create from "@/components/HomePage/Create";
import Friends from "@/components/HomePage/Friends";
import Milk from "@/components/HomePage/Milk";
import Terminal from "@/components/HomePage/Terminal";
import PageEnd from "@/components/PageEnd";

export default {
  name: "HomePage",
  components: {
    Create, Friends, Milk, Terminal,PageEnd
  }
}
</script>

<style scoped>
  #homepage{
    //display: flex;
    //flex-direction: column;
    //width: 100%;
  }
</style>