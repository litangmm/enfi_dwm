<template>
  <div id="story" class="pageFlexColumnContainer">
    <div class="create-img">

    </div>
    <div class="story-text pageMainContainer">
      <Menu></Menu>
      <router-view></router-view>
    </div>
<!--    <SPageEnd></SPageEnd>-->
    <PageEnd></PageEnd>
  </div>
</template>

<script>
import Menu from "@/components/Story/Menu";
// import SPageEnd from "@/components/Story/SPageEnd";
import PageEnd from "@/components/PageEnd";
export default {
  name: "Story",
  components:{
    Menu,
    // SPageEnd,
    PageEnd,
  },
}
</script>

<style scoped>
#story{
  min-height: 48.49vw;
  height: 100vh;
  background-color: #000;: rgba(105, 115, 124, 1);
  color: #FFFFFF;
  background-image: url("../assets/img/model.png");
  background-position: center center;
  background-size: cover;
}

#story h1{
  font-size: var(--40in1980);
}
#story h2{
  font-size: var(--20in1980);
}
#story p{
  font-size: var(--16in1980);
}
.story-text{
  height: var(--494in1980);
  display: grid;
  margin: auto;
  grid-template-columns: 15.1% 83%;
  grid-gap: var(--54in1980);
}
.story-text Menu{
  grid-column: 1/2;
  grid-row: 1/2;
}
.story-text router-view{
  grid-column: 2/3;
  grid-row: 1/2;
}

.story-text .router-view-container{
  background-color: rgba(13, 29, 35, 0.46);
  padding: var(--108in1980) var(--16in1980) 0 var(--50in1980);
}

#story #pageend{
  background: rgba(13, 29, 35, 0.7);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 1em 0;
  position: relative;
}
</style>
