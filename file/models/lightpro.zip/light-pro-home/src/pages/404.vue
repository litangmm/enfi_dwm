<template>
  <div id="page_404">
    Page Not Found
  </div>
</template>

<script>
export default {
}
</script>

<style scoped>
  #page_404{
    display: flex;
    height: 100vh;
    min-height: 300px;
    width: 100vw;
    font-size: 10vw;
    background-color: #45525b;
    justify-content: center;
    align-items: center;
  }
</style>
