<template>
  <div id="friends">
    <p>{{ $t('message.homepage_friends_1') }}</p>
    <div class="iconsContainer pageMainContainer" v-for="item in friends" v-bind:key="item.title">
      <div class="head">
        <p>{{ $t('message')[item.title]  }}</p>
        <p class="shadow"></p>
      </div>
      <div class="icons">
        <div class="icon" v-for="i in item.list" v-bind:key="i.img">
          <img v-bind:src="i.img" alt="">
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Friends",
  data() {
    return {
      friends: [
        {
          title: 'homepage_friends_tag_1',
          list: [
            {img: require('../../assets/img/friends/1@2x.png')},
            {img: require('../../assets/img/friends/2@2x.png')},
          ]
        },
        {
          title: 'homepage_friends_tag_2',
          list: [
            {img: require('../../assets/img/friends/3@2x.png')},
            {img: require('../../assets/img/friends/4@2x.png')},
            {img: require('../../assets/img/friends/5@2x.png')},
            {img: require('../../assets/img/friends/6@2x.png')},
            {img: require('../../assets/img/friends/7@2x.png')},
            {img: require('../../assets/img/friends/basf.png')},
            {img: require('../../assets/img/friends/8@2x.png')},
            {img: require('../../assets/img/friends/9@2x.png')},
            {img: require('../../assets/img/friends/10@2x.png')},
          ]
        },
        {
          title: 'homepage_friends_tag_3',
          list: [
            {img: require('../../assets/img/friends/11@2x.png')},
            {img: require('../../assets/img/friends/12@2x.png')},
          ]
        },
      ]
    }
  },
}
</script>

<style scoped>
#friends {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: #FFFFFF;
  padding: 40px 0;
}

#friends {
  background:  var(--624in1980) var(--124in1980) url("../../assets/img/slzndx.png") no-repeat;
  background-size: var(--1358in1980) var(--1034in1980);
}

#friends>p{
  font-size: var(--40in1980);
  font-weight: 747;
  margin: 0 auto 1em;
}

p {
  color: #2C2C2C;
  font-weight: 500;
  font-size: var(--26in1980);
  margin: 2em 0 0.9em;
}

.head{
  position: relative;
  display: inline-block;
}

.iconsContainer .shadow {
  height: 0.8em;
  width: 4em;
  background-color: #9ADF7F;
  border-radius: 0.1em;
  position: absolute;
  right: -1em;
  bottom: -0.2em;
  z-index: -1;
}

.icons {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  grid-gap: 1.5rem 0.5rem;
  margin-bottom: 1rem;
}

.icons, .icon {
  margin: 0.26rem;
}

.icon > img {
  height: var(--112in1980);
}

@media (min-width: 500px) {
  .icons {
    grid-template-columns: repeat(4,1fr);
  }
}

</style>
