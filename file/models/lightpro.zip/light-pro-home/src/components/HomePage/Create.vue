<template>
  <div id="create">
    <div class="create-img">
      <img src="../../assets/img/background/homepagenew@2x.png"
           alt="" @load="loadImg">
    </div>
    <div class="create-text pageMainContainer">
      <p :class="show?'is-visible':'fade-in-section'" :id="$i18n.locale=='en'?'en':''">{{$t('message')['homepage_create_1']}}</p>
      <p :class="show?'is-visible':'fade-in-section'">{{$t('message')['homepage_create_2']}}</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "Create",
  data(){
    return{
      show: false,
      // homepage: {
      //   word1: '自然之源  轻补之选',
      //   word2:'Created by nature, transformed by LightPro.',
      // },
    }
  },
  methods:{
    loadImg(){
      this.show = true
    },
  },
}
</script>

<style scoped>
#create {
  width: 100vw;
  height: 48.54vw;
  background-color: black;
  color: #FFFFFF;
  position: relative;
}

#create .create-img,#create .create-text{
  width: 100%;
  height: 100%;
}

.create-img img{
  width: 100%;
}

#create p{
  margin: 0.5em;
}

.create-text{
  position: absolute;
  top:0;
  bottom: 0;
  right: 0;
  left: 0;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.create-text p:nth-child(1){
  display: flex;
  font-size: var(--82in1980);
  word-wrap: break-word;
  line-height: 1.2em;
}

.create-text #en{
  font-size: var(--46in1980);
}

.create-text p:nth-child(2){
  font-size: var(--26in1980);
}

.create-text>p{
  transition: opacity 1200ms ease-out,
  transform 600ms ease-out,
  visibility 1200ms ease-out;
}

.fade-in-section {
  opacity: 0;
  transform: translateY(4rem);
  visibility: hidden;
}

.is-visible {
  opacity: 1;
  transform: none;
  visibility: visible;
}

</style>
