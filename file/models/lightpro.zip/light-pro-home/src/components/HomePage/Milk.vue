<template>
  <div id="milk" class="pageMainContainer">
    <div class="top">
      <div class="cups">
        <div class="cup-1">
          <img src="../../assets/img/cups/cup1@3x.png" alt="棕色瓶子">
        </div>
        <div class="cup-2">
          <img src="../../assets/img/cups/cup2@3x.png" alt="橘红色瓶子">
        </div>
        <div class="cup-3">
          <img src="../../assets/img/cups/cup3@3x.png" alt="靛蓝色瓶子">
        </div>
      </div>
      <div :class="'tag '+$i18n.locale">{{$t('message')['homepage_milk_1']}}</div>
    </div>
    <div class="icons">
      <div class="icon" v-for="item of iconList" :key="item.text">
        <i v-bind:class="'iconfont '+ item.img"> </i>
        <p>{{ $t('message')[item.text] }}</p>
      </div>
    </div>
    <div class="bottom">
      <button class="btn" @click="toMiniMeal">{{$t('message')['homepage_milk_2']}}</button>
    </div>
  </div>

</template>

<script>
export default {
  name: "Milk",
  data() {
    return {
      iconList: [
        {img: 'icon-zhiwuji_3x_1_', text: 'homepage_milk_tag_1'},
        {img: 'icon-jianadawandou_3x_1_', text: 'homepage_milk_tag_2'},
        {img: 'icon-quanqiugongyinglian_3x_1_', text: 'homepage_milk_tag_3'},
        {img: 'icon-fuhanweisheng_3x_1_', text: 'homepage_milk_tag_4'},
        {img: 'icon-chaojiyishengjun_3x_1_', text: 'homepage_milk_tag_5'},
        {img: 'icon-fuhanweisheng-kaobei_2x', text: 'homepage_milk_tag_6'},
        {img: 'icon-wutang_3x_1_', text: 'homepage_milk_tag_7'},
        {img: 'icon-direliang', text: 'homepage_milk_tag_8'},
        {img: 'icon-feizhuanjiyin_3x_1_', text: 'homepage_milk_tag_9'},
        {img: 'icon-huanjingyouhao_3x_1_', text: 'homepage_milk_tag_10'},
      ],
    }
  },
  methods:{
    toMiniMeal(){
      this.$router.push({
        name: 'minimeal',
      })
    },
  },
}
</script>

<style scoped>
#milk {
  height: 54.80vw;
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  align-items: center;
  margin: auto;
}

.top {
  height: 40%;
  width: var(--840in1980);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  position: relative;
}

.top .cups {
  width: inherit;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 var(--124in1980) 0;
}

.cups>div{
  transition: 0.5s;
  transform: translateY(25%);
}

.cups>div:hover{
  transform: translateY(0%);
}

img {
  width: var(--148in1980);
  height: 100%;
}

.tag {
  font-size: var(--40in1980);
  display: flex;
  //justify-content: center;
  align-items: center;
  height: 3em;
  padding: 0 4em;
  color: white;
  background-color: #6DA656;
  border-radius: var(--10in1980);
  z-index: 99;
  overflow: hidden;
}

.en{
  padding: 0 1em;
}

.icons {
  width: 100%;
  display: grid;
  grid-template-columns:repeat(5, 1fr);
  grid-template-rows: repeat(2,1fr);
  grid-gap: var(--88in1980) var(--54in1980);
  font-size: var(--108in1980);
  justify-items: center;
  margin: 1rem auto;
}

.icon p {
  width: 100%;
  text-align: center;
  //white-space: nowrap;
  //overflow: hidden;
  //text-overflow: ellipsis;
  font-size: var(--24in1980);
}

.icon {
  display: flex;
  position: relative;
  justify-content: flex-start;
  align-items: center;
  flex-direction: column;
  max-width: 10vw;
  width: 100%;
  transition: 0.5s;
}

.icons .icon i{
  font-size: var(--108in1980);
}

.icons .icon:hover{
  color: #6DA656;
}

.bottom {
  display: flex;
  justify-items: center;
  align-items: center;
  margin: 0 auto 1.2rem;
}

.bottom .btn {
  height: var(--50in1980);
  width: var(--195in1980);
  background-color: #6DA656;
  color: #FFFFFF;
  border-radius: 100px;
  letter-spacing: 0.1em;
  font-size: var(--24in1980);
  border: none;
  cursor: pointer;
}


</style>
