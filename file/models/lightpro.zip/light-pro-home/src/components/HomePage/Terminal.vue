<template>
  <div id="terminal">
    <div class="terminal-img">
      <img src="../../assets/img/background/terminal@2x.png" alt="智能设备">
    </div>
    <div class="terminal-text">
      <h1 id="top">{{ $t('message.homepage_terminal_1') }}</h1>
      <div class="around">
        <div class="left">
          <div class="left-more-item">
            <p class="tag">{{ $t('message.homepage_terminal_tag_1') }}</p>
            <div class="sharpe">
              <div class="line"></div>
              <div class="circle"></div>
            </div>
          </div>
          <div class="left-item">
            <p class="tag">{{ $t('message.homepage_terminal_tag_2') }}</p>
            <div class="sharpe">
              <div class="line"></div>
              <div class="circle"></div>
            </div>
          </div>
          <div class="left-more-item">
            <p class="tag">{{ $t('message.homepage_terminal_tag_3') }}</p>
            <div class="sharpe">
              <div class="line"></div>
              <div class="circle"></div>
            </div>
          </div>
          <div class="left-item">
            <p class="tag">{{ $t('message.homepage_terminal_tag_4') }}</p>
            <div class="sharpe">
              <div class="line"></div>
              <div class="circle"></div>
            </div>
          </div>
          <div class="left-more-item">
            <p class="tag">{{ $t('message.homepage_terminal_tag_5') }}</p>
            <div class="sharpe">
              <div class="line"></div>
              <div class="circle"></div>
            </div>
          </div>
        </div>
        <div class="right">
          <div class="right-more-item">
            <p class="tag">{{ $t('message.homepage_terminal_tag_6') }}</p>
            <div class="sharpe">
              <div class="circle"></div>
              <div class="line"></div>
            </div>
          </div>
          <div class="right-item">
            <p class="tag">{{ $t('message.homepage_terminal_tag_7') }}</p>
            <div class="sharpe">
              <div class="circle"></div>
              <div class="line"></div>
            </div>
          </div>
          <div class="right-more-item">
            <p class="tag">{{ $t('message.homepage_terminal_tag_8') }}</p>
            <div class="sharpe">
              <div class="circle"></div>
              <div class="line"></div>
            </div>
          </div>
          <div class="right-item">
            <p class="tag">{{ $t('message.homepage_terminal_tag_9') }}</p>
            <div class="sharpe">
              <div class="circle"></div>
              <div class="line"></div>
            </div>
          </div>
          <div class="right-more-item">
            <p class="tag">{{ $t('message.homepage_terminal_tag_10') }}</p>
            <div class="sharpe">
              <div class="circle"></div>
              <div class="line"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="bottom">
        <div class="bottom-blocks" v-if="false">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
        <button class="btn"  @click="toTerminal">{{$t('message.homepage_terminal_2')}}</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Terminal",
  methods: {
    toTerminal(){
      this.$router.push({
        name: 'terminal',
      })
    },
  },
  watch: {
    '$i18n.locale':function (){
      console.log('i know it')
    },
  },
}
</script>

<style scoped>


#terminal {
  width: 100vw;
  height: 46.97vw;
  color: #FFFFFF;
  position: relative;
  background-color: RGBA(229, 227, 222, 1);
}

.terminal-img {
  width: 100%;
}

.terminal-img img {
  width: 100%;
}

.terminal-text {
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  color: black;
}

#top {
  font-weight: 600;
  height: 19.4%;
  display: flex;
  align-items: center;
}

.around {
  height: 57%;
  line-height: 1.12rem;
  display: flex;
  justify-content: space-evenly;
  align-items: stretch;
  font-size: var(--28in1980);
}

.terminal-text #top {
  font-size: var(--40in1980);
}

.left > p, .right > p {
  border-bottom: 1px solid #FFFFFF;
}

.left, .right {
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  width: 15em;
  margin: 0 0 0 4vw;
}
.left {
  text-align: left;
  align-items: flex-start;
  //margin: 0 4vw 0 calc(-1*var(--16in1980));
  margin: 0 4vw 0 0;
}
.left p{
  padding:0 0.1em 0 0;

}

.right p{
  padding: 0 0 0 0.1em;
}

p[class="tag"]{
  transition: 0.5s;
}
p[class="tag"]:hover {
  //font-size: var(--36in1980);
  transform: scale(1.2);
}

.right {
  text-align: right;
  align-items: flex-end;
}

.left-more-item, .right-more-item {
  width: 100%;
}

.left-item, .right-item {
  width: calc(100% - 2em);
  margin-left: 2em;
}

.right-item {
  margin-right: 2em;
}

.bottom {
  height: 23.7%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
}

.bottom .bottom-blocks{
  display: flex;
}

.bottom .bottom-blocks>div{
  width: var(--108in1980);
  height: var(--24in1980);
  background-color: rgba(242, 188, 59, 1);
  margin: 0 var(--16in1980) var(--26in1980);
  border-radius: calc(var(--16in1980)/4);
}
.bottom .bottom-blocks>div:nth-child(2){
  background-color: rgba(109, 166, 86, 1);
}

.bottom .bottom-blocks>div:nth-child(3){
  background-color: rgba(48, 206, 145, 1);
}

.bottom .bottom-blocks>div:nth-child(4){
  background-color: rgba(244, 34, 103, 1);
}

.bottom .btn {
  height: var(--50in1980);
  width: var(--195in1980);
  background-color: #6DA656;
  color: #FFFFFF;
  border-radius: 100px;
  letter-spacing: 0.1em;
  font-size: var(--24in1980);
  border: none;
  cursor: pointer;
}
.sharpe {
  margin: var(--14in1980) 0 0;
  height: calc(var(--24in1980) / 3);
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.sharpe .line {
  display: inline-block;
  height: calc(var(--12in1980) / 6);
  background-color: white;
  flex: 1;
}

.sharpe .circle {
  height: 100%;
  width: calc(var(--24in1980) / 3);
  display: inline-block;
  border-radius: 999px;
  border: 1px white solid;
}

</style>
