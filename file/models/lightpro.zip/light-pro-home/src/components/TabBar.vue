<template>
  <div class="pageMainContainer" id="tabBar">
    <div class="menu">
      <router-link to="/HomePage">
        <div class="logo">
          <img src="../assets/img/lightProLogo.png" alt="">
        </div>
      </router-link>
    </div>
    <div class="menu-dropdown" :hidden="showMenu">
      <ul v-on:click="onIClick">
        <li>
          <router-link to="/homepage">{{ $t('message')['tabbar-home'] }}</router-link>
        </li>
        <li>
          <router-link to="/minimeal">{{ $t('message')['tabbar-minimeal'] }}</router-link>
        </li>
        <li>
          <router-link to="/terminal">{{ $t('message')['tabbar-terminal'] }}</router-link>
        </li>
        <li>
          <router-link to="/story/concept">{{ $t('message')['tabbar-story'] }}</router-link>
        </li>
        <li>
          <a href="https://mall.jd.com/index-10330379.html" target="_blank">{{ $t('message')['tabbar-shopping'] }}</a>
        </li>
      </ul>
    </div>
    <div class="changeLang">
      <div :class="$i18n.locale === 'zh'?'active':''" @click="changeToZH">{{ $i18n.locale === 'en' ? '中文' : '中文' }}
      </div>
      <div :class="$i18n.locale === 'en'?'active':''" @click="changeToEN">{{ $i18n.locale === 'en' ? 'EN' : 'EN' }}
      </div>
    </div>
    <!--    <a -->
    <!--       style="background: rgba(255,255,255,0);color: #FFFFFF">{{ $t('message.tabbar-changeLang') }}</a>-->
  </div>
</template>

<script>

export default {
  name: 'TabBar',
  props: {},
  data() {
    return {
      showMenu: true,
    }
  },
  created() {

  },
  methods: {
    onIClick: function () {
      this.showMenu = !this.showMenu
    },
    changeToEN() {
      if(this.$i18n.locale === 'zh'){
        this.$i18n.locale = 'en'
        localStorage.setItem('locale', 'en')
      }

    },
    changeToZH() {
      if(this.$i18n.locale === 'en'){
        this.$i18n.locale = 'zh'
        localStorage.setItem('locale', 'zh')
      }
    }
  },
}
</script>

<style scoped>
#tabBar {
  margin: 1rem auto;
  position: absolute;
  right: 50%;
  transform: translateX(50%);
  display: flex;
  justify-content: flex-start;
  align-items: center;
  background: rgba(255, 255, 255, 0) !important;
  top: 0;
  height: 3em;
  z-index: 99;
  user-select: none;
}

.logo {
  height: 2.31rem;
  margin-right: 1em;
}

.logo img {
  height: 100%;
}

.menu-dropdown {
  display: inline-block;
  background: rgba(255, 255, 255, 0) !important;
}

.menu-dropdown ul {
  list-style-type: none;
  display: flex;
  justify-content: space-around;
  align-items: center;
}

.menu-dropdown ul li {
  transition: 0.2s;
  display: inline-block;
  width: auto;
  padding: 0 0.9em;
}

.menu-dropdown ul li:hover {
  transform: scale(1.1);
  font-size: var(--20in1980);
  font-weight: bold;
}

.menu-dropdown a {
  font-size: var(--18in1980);
  font-weight: normal;
  padding: 0.2em 0.5em;
  color: #FFFFFF;
  text-decoration: none;
}

.menu-dropdown a:hover {
  border-bottom: #30CE91 solid 2px;
}

.changeLang {
  display: flex;
  margin-left: auto;
  border-radius: calc(var(--12in1980) / 2);
  overflow: hidden;
  justify-content: flex-start;
  align-items: center;
  width: fit-content;
  height: fit-content;
  padding: 0;
}

.changeLang div {
  width: 4em;
  height: 2em;
  font-size: var(--16in1980);
  //padding: 0.2em 0.8em;
  //display: flex;
  border: 1px rgba(255, 255, 255, 1) solid;
  border-radius: calc(var(--12in1980) / 2);
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 0;
  transition: 0.5s;
}
.changeLang div:nth-child(1){
  border-right: none;
  border-radius: calc(var(--12in1980) / 2) 0 0 calc(var(--12in1980) / 2);

}
.changeLang div:nth-child(2){
  border-left: none;
  border-radius: 0 calc(var(--12in1980) / 2) calc(var(--12in1980) / 2) 0;
}
.changeLang .active {
  background: rgba(255, 255, 255, 1);
  color: black;
  cursor: pointer;
}

.changeLang {
  background: rgba(255, 255, 255, 0);
  color: white;
  cursor: pointer;
}

</style>
