<template>
  <div id="what">
    <div class="ps">
      <p>{{$t('message.minimeal_what_1')}}</p>
      <p>{{$t('message.minimeal_what_2')}}</p>
    </div>
    <div v-if="$i18n.locale=='en'" class="imgs" @mouseover="stop = true" @mouseleave="stop = false">
      <img @click="activeImg = 1" v-bind:id="activeImg===1?'imgcenter':activeImg===2?'imgleft':'imgright'"
           src="../../assets/img/minimeal/Card2EN.png" alt="">
      <img @click="activeImg = 2" v-bind:id="activeImg===1?'imgright':activeImg===2?'imgcenter':'imgleft'"
           src="../../assets/img/minimeal/Card3EN.png" alt="">
      <img @click="activeImg = 3" v-bind:id="activeImg===1?'imgleft':activeImg===2?'imgright':'imgcenter'"
           src="../../assets/img/minimeal/Card4EN.png" alt="">
    </div>
    <div v-else class="imgs" @mouseover="stop = true" @mouseleave="stop = false">
      <img @click="activeImg = 1" v-bind:id="activeImg===1?'imgcenter':activeImg===2?'imgleft':'imgright'"
           src="../../assets/img/minimeal/Card2.png" alt="">
      <img @click="activeImg = 2" v-bind:id="activeImg===1?'imgright':activeImg===2?'imgcenter':'imgleft'"
           src="../../assets/img/minimeal/Card3.png" alt="">
      <img @click="activeImg = 3" v-bind:id="activeImg===1?'imgleft':activeImg===2?'imgright':'imgcenter'"
           src="../../assets/img/minimeal/Card4.png" alt="">
    </div>
  </div>
</template>

<script>
export default {
  name: "What",
  data() {
    return {
      activeImg: 2,
      stop: false,
    }
  },
  created() {
    setInterval(() => {
      if (!this.stop) {
        let activeImg = this.activeImg + 1
        this.activeImg = activeImg > 3 ? 1 : activeImg
      }
    }, 3600)
  },
}
</script>

<style scoped>
#what {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  height: 45.48vw;
  padding: var(--108in1980) 0;
}

.ps {
//margin: 2.64rem 0 ; margin-bottom: calc(72 / 1980 * 1vw);
  color: #2C2C2C;
  text-align: center;
}


.ps p:nth-child(1) {
  font-size: var(--40in1980);
  font-weight: 767;
}

.ps p:nth-child(2) {
  font-size: var(--18in1980);
  margin-top: 1em;
//margin-bottom: 2em;
}

@media (max-width: 767px) {
  .ps p:nth-child(2) {
    font-size: 0.46rem;
    margin-bottom: 1em;
  }
}

.imgs {
  margin: 0 auto;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: var(--534in1980);
}

.imgs img {
  display: inline-block;
  width: var(--770in1980);
  height: var(--474in1980);
  position: absolute;
  transition: 0.4s;
}

#imgleft {
  transform: translateX(-20%);
  z-index: 10;
  cursor: pointer;
}

#imgcenter {
  margin: 0;
  width: var(--770in1980);
  height: var(--534in1980);
  z-index: 11;
}


#imgright {
  transform: translateX(20%);
  z-index: 10;
  cursor: pointer;
}

</style>
