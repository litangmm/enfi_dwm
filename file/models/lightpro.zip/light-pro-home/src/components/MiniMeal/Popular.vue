<template>
  <div id="popular">
    <p>{{$t('message.minimeal_popular_1')}}</p>
    <p>{{$t('message.minimeal_popular_2')}}</p>
  </div>
</template>

<script>
export default {
  name: "Popular"
}
</script>

<style scoped>
  #popular{
    height: 20.91vw;
    font-size: var(--58in1980);
    font-weight: 400;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #2C2C2C;
    color: #FFFFFF;
    background-image: url("../../assets/img/minimeal2@1x.png");
    background-size: cover;
  }
  #popular p:nth-child(1){
    margin-right: 2em;
  }
</style>
