<template>
  <div id="love">
    <div class="pageMainContainer">
      <div class="love-header">
        <h1>{{ $t(text + 1) }}</h1>
        <p>{{ $t(text + 2) }}</p>
        <p>{{ $t(text + 3) }}</p></div>
      <div class="content-1">
        <h2>{{ $t(text + 4) }}</h2>
        <div class="line"></div>
        <p>{{ $t(text + 5) }}</p>
        <p>{{ $t(text + 6) }}</p>
      </div>
      <div class="content-2">
        <h2>{{ $t(text + 7)}}</h2>
        <div class="line"></div>
        <div class="content-21">
          <div>
            <p v-for="a in arrays" :key="a">
              {{ $t( text + (a + 7)) }}
            </p>
          </div>
          <div>
            <p v-for="a in arrays" :key="a">
              {{ $t( text + (a + 16)) }}
            </p>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>
<script>export default {
  name: "Love"
  , data() {
    return {
      text: 'message.minimeal_love_',
      arrays : [1,2,3,4,5,6,7,8,9],
    }
  }
}</script>
<style scoped>

#love {
  background-color: #2C2C2C;
  color: #ffffff;
  width: 100%;
  padding: var(--74in1980) 0 var(--88in1980);
  background-image: url("../../assets/img/minimeal3.png");
  background-size: cover;
}

#love .love-header h1 {
  font-size: var(--40in1980);
  font-weight: 767;
  margin-bottom: 0.75em;
  text-align: center;
}

#love .content-1 > h2, #love .content-2 > h2 {
  font-size: var(--26in1980);
  line-height: 2em;
  vertical-align: center;
  font-weight: 500;
}

#love h1 {
  width: 100%;
}


h2 {
  margin-top: 1.38em;
}

.line {
  width: var(--50in1980);
  height: calc(var(--12in1980) / 6);
  background-color: #ffffff;
}

#love p {
  max-width: 100vw;
  font-size: var(--18in1980);
  line-height: 2em;
  vertical-align: center;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

#love .content-2 p {
  font-size: var(--18in1980);
  line-height: 2em;
  vertical-align: center;
  overflow: hidden;
}

.content-2 {
  width: 100%;
}

.content-21 {
  display: flex;
  width: 100%;
  justify-content: space-between;
  flex-wrap: wrap;
}

.content-21 > div > p {
  width: 100%;
}

</style>
