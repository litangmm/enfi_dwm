<template>
  <div id="tastes" class="pageMainContainer">
    <h1>{{$t('message.minimeal_tastes_1')}}</h1>
    <div v-if="$i18n.locale=='en'" class="imgs">
      <img src="../../assets/img/taste/hongdouEN.png" alt="">
      <img src="../../assets/img/taste/yanmaiEN.png" alt="">
      <img src="../../assets/img/taste/hetaoEN.png" alt="">
    </div>
    <div v-else class="imgs">
      <img src="../../assets/img/taste/hongdou.png" alt="">
      <img src="../../assets/img/taste/yanmai.png" alt="">
      <img src="../../assets/img/taste/hetao.png" alt="">
    </div>
    <div class="more">
      <h1>{{$t('message.minimeal_tastes_2')}}</h1>
      <img src="../../assets/img/taste/more@2x.png" alt="">
    </div>
  </div>
</template>

<script>
export default {
  name: "Tastes"
}
</script>

<style scoped>
  #tastes{
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  .imgs{
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  img{
    height: var(--400in1980);
    max-width: 100vw;
    position: relative;
    margin-bottom: 1.1rem;
    transition: 0.5s;
  }

  .imgs img:hover{
    transform: scale(1.15);
    //right: 0;
    //left: 0;
  }
  @media (min-width: 870px) {
    .imgs{
      //overflow: hidden;
    }
    .imgs img:hover{
      transform: scale(1.10);
    }
  }

  .imgs>img:nth-child(1),.imgs>img:nth-child(3){
    right: 1.65rem;
  }

  .imgs>img:nth-child(2){
    left: 1.85rem;
  }

  .more img{
    height: var(--138in1980);
    margin-top: var(--40in1980) ;
    width: auto;
  }


  #tastes h1{
    font-size: var(--40in1980);
    font-weight: 767;
    color: #2C2C2C;
  }
  #tastes>h1:nth-child(1){
    //padding: 2.67rem 0;
    margin: var(--124in1980) 0;
  }
  #tastes .more{
    margin: var(--148in1980) 0 var(--214in1980);
    display: flex;
    flex-direction: column;
    align-items: center;
  }

</style>
