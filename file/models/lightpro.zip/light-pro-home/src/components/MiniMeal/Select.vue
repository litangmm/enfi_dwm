<template>
  <div id="select">
    <div class="select-img">
      <img src="../../assets/img/minimeal@2x.png" alt="">
    </div>
    <div class="select-text">
      <p :id="$i18n.locale=='en'?'en':''">{{$t('message.minimeal_select_1')}}</p>
      <p>{{$t('message.minimeal_select_2')}}</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "Select"
}
</script>

<style scoped>
#select {
  width: 100vw;
  height: 39.49vw;
  background-color: black;
  color: #FFFFFF;
  position: relative;

}

.select-img img{
  width: 100%;
}
#select p{
  margin: 0.5em;
}

.select-text{
  position: absolute;
  top:0;
  bottom: 0;
  right: 0;
  left: 0;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
.select-text p:nth-child(1){
  display: flex;
  font-size: var(--74in1980);
  word-wrap: break-word;
  line-height: 1.2em;
}
.select-text #en{
  font-size: var(--46in1980);
}
.select-text p:nth-child(2){
  font-size: var(--28in1980);
}
</style>
