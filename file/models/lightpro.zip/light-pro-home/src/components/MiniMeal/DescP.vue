<template>
  <div id="desc" class="pageMainContainer">
    <div class="header">
      <h1>{{$t('message.minimeal_descp_1')}}</h1>
      <p>{{$t('message.minimeal_descp_2')}}</p>
    </div>
    <div class="content">
      <div class="left">
        <img src="../../assets/img/cups@2x.png" alt="">
      </div>
      <div class="right">
        <h2>{{$t('message.minimeal_descp_3')}}</h2>
        <div class="texts">
          <p v-for="text in texts" v-bind:key="text">{{ $t('message')[text] }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "DescP",
  data() {
    return {
      texts: [
        'minimeal_descp_p_1',
        'minimeal_descp_p_2',
        'minimeal_descp_p_3',
        'minimeal_descp_p_4',
        'minimeal_descp_p_5',
        'minimeal_descp_p_6',
        'minimeal_descp_p_7',
        'minimeal_descp_p_8',
        'minimeal_descp_p_9',
        'minimeal_descp_p_10',
        'minimeal_descp_p_11',
        'minimeal_descp_p_12',
        'minimeal_descp_p_13',
      ]
    }
  },
}
</script>

<style scoped>
#desc {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: var(--108in1980) 0;
}

#desc .header {
  text-align: center;
//padding: 0 2.27rem; margin-bottom: var(--88in1980);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

#desc .header h1 {
  font-size: var(--40in1980);
  font-weight: 767;
  color: #2C2C2C;
}

#desc .content {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
}

#desc .right {
  min-width: 20em;
}

#desc .left {
  height: var(--410in1980);
}

#desc .left img {
  height: 100%;
}

#desc .right h2 {
  font-size: var(--26in1980);
  font-weight: 500;
}

#desc .header p {
  font-size: var(--18in1980);
  padding: 1em 0;
}

#desc .right p {
  font-size: var(--18in1980);
  margin: 1em 0;
}

</style>
