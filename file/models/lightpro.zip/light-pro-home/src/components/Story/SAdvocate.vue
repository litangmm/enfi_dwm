<template>
  <div id="s-advocate" class="router-view-container">
    <h1>{{$t('message.story_sadvocate_h1')}}</h1>
    <div class="line"></div>
    <h2>{{$t('message.story_sadvocate_h2')}}</h2>
    <p>{{$t('message.story_sadvocate_p')}}</p>
  </div>
</template>

<script>
export default {
name: "SAdvocate"
}
</script>

<style scoped>
  #s-advocate{

  }

  .line{
    width: var(--108in1980);
    height: calc(var(--12in1980)/3);
    background-color: #FFFFFF;
    margin: var(--22in1980) 0;
  }
</style>
