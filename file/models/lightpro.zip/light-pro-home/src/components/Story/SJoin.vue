<template>
  <div id="s-join" class="router-view-container">
    <h1>{{$t('message.story_sjoin_h1')}}</h1>
    <div class="line"></div>

    <div class="contacts-item">
      <img src="../../assets/img/story/youxiang.png" alt="">
      <p>{{$t('message.story_sjoin_p')}}</p>
    </div>
  </div>
</template>

<script>
export default {
name: "SJoin"
}
</script>

<style scoped>
#s-join{

}
.line{
  width: var(--108in1980);
  height: calc(var(--12in1980)/3);
  background-color: #FFFFFF;
  margin: var(--22in1980) 0;
}

#s-join .contacts-item img{
  width: var(--46in1980);
  margin-right: calc(var(--12in1980)/3);
}

#s-join .contacts-item {
  display: flex;
  align-items: center;
  margin: var(--46in1980) 0 0 var(--46in1980);
}
</style>
