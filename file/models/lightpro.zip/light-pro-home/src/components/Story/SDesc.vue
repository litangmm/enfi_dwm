<template>
  <div id="s-desc"  class="router-view-container">
    <h1>{{$t('message.story_sdesc_h1')}}</h1>
    <div class="line"></div>
    <p>{{$t('message.story_sdesc_p1')}}</p><br/>
    <p>{{$t('message.story_sdesc_p2')}}</p><br/>
    <p>{{$t('message.story_sdesc_p3')}}</p><br/>
  </div>
</template>

<script>
export default {
name: "SDesc"
}
</script>

<style scoped>
#s-desc{

}

.line{
  width: var(--108in1980);
  height: calc(var(--12in1980)/3);
  background-color: #FFFFFF;
  margin: var(--22in1980) 0;
}
</style>
