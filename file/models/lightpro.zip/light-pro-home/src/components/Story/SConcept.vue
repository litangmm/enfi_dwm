<template>
  <div id="s-concept" class="router-view-container">
    <h1>{{$t('message.story_sconcept_h1')}}</h1>
    <div class="line"></div>
    <p>{{$t('message.story_sconcept_p1')}}</p>
    <br v-if="$i18n.locale=='en'"/>
    <p>{{$t('message.story_sconcept_p2')}}</p>
    <br v-if="$i18n.locale=='en'"/>

    <p>{{$t('message.story_sconcept_p3')}}</p>
    <br v-if="$i18n.locale=='en'"/>

    <p>{{$t('message.story_sconcept_p4')}}</p>
    <br v-if="$i18n.locale=='en'"/>

    <p>{{$t('message.story_sconcept_p5')}}</p>
    <br v-if="$i18n.locale=='en'"/>

    <p>{{$t('message.story_sconcept_p6')}}</p>
    <br v-if="$i18n.locale=='en'"/>

  </div>
</template>

<script>
export default {
  name: "SConcept"
}
</script>

<style scoped>
#s-concept {

}

.line{
  width: var(--108in1980);
  height: calc(var(--12in1980)/3);
  background-color: #FFFFFF;
  margin: var(--22in1980) 0;
}
</style>
