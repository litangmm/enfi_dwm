<template>
  <div id="menu">
    <ul v-for="router in routers" v-bind:key="router.id">
      <li :class="$route.path===router.to?'active':' '" @click="activeLi(router.id,router.to)">
        <p class="block" v-if="$route.path===router.to"></p>
        <p>{{ $t('message.' + router.text) }}</p>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: "Menu",
  data() {
    return {
      activeId: 1,
      routers: [
        {
          id: 1,
          text: "story_sconcept_h1",
          to: "/story/concept",
        }, {
          id: 2,
          text: "story_sdesc_h1",
          to: "/story/desc",
        }, {
          id: 3,
          text: "story_sadvocate_h1",
          to: "/story/advocate",
        }, {
          id: 4,
          text: "story_scontact_h1",
          to: "/story/contact",
        }, {
          id: 5,
          text: "story_sjoin_h1",
          to: "/story/join",
        },
      ]
    }
  },
  methods: {
    activeLi(id,to){
      if(this.$route.path !== to){
        this.$router.replace(to);
        this.activeId = id;
      }
      console.log(this.$router)
    }
  },
}
</script>

<style scoped>
#menu li {
  height: var(--60in1980);
  line-height: var(--60in1980);
  background-color: rgba(16, 25, 36, 0.6);

  text-align: center;
  font-size: var(--18in1980);
  color: #FFFFFF;
  margin-bottom: calc(var(--12in1980)/3);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}

#menu li p{
  display: inline-block;
  color: #FFFFFF;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

#menu li[class=active]{
  background-color: rgba(150, 150, 152, 0.6);
}
#menu li .block{
  height: 1em;
  width: 1em;
  margin-right:  1em ;
  background-color: rgba(254, 100, 55, 1);
}



</style>
