<template>
  <div id="s-contact" class="router-view-container">
    <h1>{{$t('message.story_scontact_h1')}}</h1>
    <div class="line"></div>

    <div :class="$i18n.locale=='en'?'contactsEn':'contacts'" >
      <div class="contacts-item">
        <img src="../../assets/img/story/dianhua.png" alt="">
        <span>{{$t('message.story_scontact_p1')}}</span>
      </div>
      <div class="contacts-item">
        <img src="../../assets/img/story/qingbu.png" alt="">
        <span>{{$t('message.story_scontact_p2')}}</span>
      </div>
      <div class="contacts-item">
        <img src="../../assets/img/story/shangwu.png" alt="">
        <span>{{$t('message.story_scontact_p3')}}</span>
      </div>
      <div class="contacts-item">
        <img src="../../assets/img/story/meiti.png" alt="">
        <span>{{$t('message.story_scontact_p4')}}</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
name: "SContact"
}
</script>

<style scoped>
#s-contact{

}

.line{
  width: var(--108in1980);
  height: calc(var(--12in1980)/3);
  background-color: #FFFFFF;
  margin: var(--22in1980) 0;
}

#s-contact .contacts{
  margin: var(--46in1980) 0 0 var(--46in1980);
  display: grid;
  grid-template-rows: 1fr 1fr;
  grid-template-columns: 1fr 1fr;
  grid-template-areas: 'a b' 'c d';
  grid-gap: var(--50in1980) 0;
}
#s-contact .contactsEn{
  margin: var(--46in1980) 0 0 var(--46in1980);
  display: grid;
  grid-template-rows: 1fr 1fr;
  grid-template-columns: 1fr 1fr;
  grid-template-areas: 'a b' 'c d';
  grid-gap: var(--50in1980) 0;
  font-size: var(--20in1980);
}

#s-contact .contacts-item img{
  width: var(--46in1980);
  margin-right: calc(var(--12in1980)/3);
}

#s-contact .contacts-item {
  display: flex;
  align-items: center;
}
#s-contact .contacts-item span{
  white-space: nowrap;
}
</style>
