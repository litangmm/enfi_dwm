<template>
  <div id="pageend">
<!--    <canvas id="bottom_Canvas" :width="c_width" :height="c_height" ref="bottom_Canvas"></canvas>-->
    <div class="top pageMainContainer">
      <div class="links">
        <p>相关链接</p>
        <div class="as">
          <a href="https://www.cargill.com.cn/">Cargill</a>
          <a href="https://www.glanbianutritionals.com/zh-hans">Glanbia</a>

          <a href="https://bc30probiotic.com/">GendenBC30</a>
          <a href="https://www.basf.com/cn/zh/industries/lifestyle.html">BASF</a>
          <a href="https://weibo.com/u/7520999653?is_all=1">微博</a>
          <a href="https://www.zhihu.com/org/qing-bu-lightpro">科普</a>
        </div>
      </div>
      <div class="qrcode">
        <img src="../../assets/img/qr.png" alt="">
        <p>微信公众号</p>
      </div>
      <div class="tel">
        <p>客服热线: 400-669-0708</p>
        <p>客服邮箱: CS@lightpro.fit</p>
      </div>
    </div>
    <div class="bottom">
      <a href="https://beian.miit.gov.cn/#/Integrated/index">京ICP备2020032477号</a>
      <a href="">公安网备案</a>
      <p>版权声明（Copyright © 2020 LightPro.）</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "SPageEnd",
  data(){
    return{
      c_width:1980,
      c_height:245,
    }
  },
}
</script>

<style scoped>
  #pageend{
    background: rgba(13, 29, 35, 0.7);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 1em 0;
    height: var(--214in1980);
    position: relative;
  }
  #pageend #bottom_Canvas{
    position: absolute;
    z-index: -1;
  }
  #pageend *{
    color: #FFFFFF;
  }

  #pageend a:hover{
    color: #6DA656;
  }

  .top{
    display: flex;
    flex-wrap: wrap;
    align-items: center;
  }

  .links{
    flex: 1;
  }

  .links>p{
    display: inline-block;
    padding-bottom: calc(var(--12in1980)/4);
    border-bottom: calc(var(--12in1980)/4) #ffffff solid ;
    margin:0 var(--32in1980) 1rem;
  }

  .links div>a{
    padding:0 var(--32in1980);
    border-right: 1px #FFFFFF solid ;
    font-size: var(--16in1980);
  }

  .links div>a:last-child{
    border-right: none;
  }

  .qrcode{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }

  .qrcode img{
    width: var(--88in1980);
  }

  .qrcode p{
    font-size: var(--12in1980);
    margin-top: 1em;
  }

  .tel{
    margin-left: 2em ;
  }
  .tel p{
    font-size: var(--16in1980);
    margin: 1em 0;
  }

  .bottom a{
    margin: 0 calc(var(--12in1980)/2);
  }
  .bottom p{
    display: inline-block;
    margin: 0 calc(var(--12in1980)/2);

  }
  .bottom{
    font-size: var(--14in1980);
  }

</style>