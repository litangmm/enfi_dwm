<template>
  <div id="t-tech">
    <div class="content">
      <div class="content-left">
        <h2>{{$t('message.terminal_ttech_1')}}</h2>
        <div class="text1" v-if="$i18n.locale!='en'">
          <p>·{{$t('message.terminal_ttech_2')}}</p>
          <p>·{{$t('message.terminal_ttech_3')}} </p>
          <p>·{{$t('message.terminal_ttech_4')}}</p>
        </div>
        <div class="text2" v-if="$i18n.locale!='en'">
          <p>·{{$t('message.terminal_ttech_5')}}</p>
          <p>·{{$t('message.terminal_ttech_6')}}</p>
          <p>·{{$t('message.terminal_ttech_7')}}</p>
        </div>
        <div class="text3" v-if="$i18n.locale=='en'">
          <p>·{{$t('message.terminal_ttech_2')}}</p>
          <p>·{{$t('message.terminal_ttech_3')}} </p>
          <p>·{{$t('message.terminal_ttech_4')}}</p>
          <p>·{{$t('message.terminal_ttech_5')}}</p>
          <p>·{{$t('message.terminal_ttech_6')}}</p>
          <p>·{{$t('message.terminal_ttech_7')}}</p>
        </div>
      </div>
      <div class="content-right">
        <img src="../../assets/img/minip@2x.png" alt="">
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "TTech"
}
</script>

<style scoped>
  #t-tech{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background: url("../../assets/img/background/miniprogramerbk.png") ;
    background-size: cover;
    height: 44.24vw;
    width: 100vw;
    color: white;
  }
  .content{
    display: flex;
    flex-wrap: wrap;
    align-items: center;
  }
  .content-left {
    display: grid;
    grid-template-columns: 19vw 19vw;
    grid-template-rows: repeat(2,10.07vw);
  }

  .content-left img{
    height: 2.27vw;
    //grid-column: 1/3;
    //grid-row: 1/2;
  }

  .content-left h2{
    grid-column: 1/3;
    grid-row: 1/2;
  }

  .content-left .text1{
    grid-column: 1/2;
    grid-row: 2/3;
  }

  .content-left .text2{
    grid-column: 2/3;
    grid-row: 2/3;
  }

  .content-left .text3{
    grid-column: 1/3;
    grid-row: 2/3;
  }

  #t-tech>h1{
    font-size: var(--40in1980);
    font-weight: 500;
    margin: 1em 0;
  }

  #t-tech .content h2{
    font-size: var(--74in1980);
  }

  #t-tech .content p{
    font-size: var(--36in1980);
  }

  .content-right img{
    width: 27.52vw;
    height: auto;
  }
</style>
