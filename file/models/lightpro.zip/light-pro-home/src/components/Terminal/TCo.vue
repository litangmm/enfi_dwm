<template>
  <div id="t-co">
    <p>{{$t('message.terminla_tco_1')}}</p>
    <p>{{$t('message.terminla_tco_2')}}</p>
  </div>
</template>

<script>
export default {
  name: "TCo"
}
</script>

<style scoped>
  #t-co{
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: var(--40in1980);
    font-weight: 767;
    margin: auto;
    padding: var(--124in1980) 0;
    flex-wrap: wrap;
  }
  #t-co p{
    padding: 0 2.5em;
  }
</style>
