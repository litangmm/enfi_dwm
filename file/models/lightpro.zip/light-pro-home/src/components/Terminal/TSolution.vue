<template>
  <div id="t-solution">
    <div class="header">
      <h1>{{$t('message.terminal_tsolution_h1')}}</h1>
    </div>
    <div class="content">
      <div class="left">
        <img src="../../assets/img/beizi.png" alt="">
      </div>
      <div class="right">
        <h2>{{$t('message.terminal_tsolution_h2')}}</h2>
        <div class="texts">
          <p v-for="text in texts" v-bind:key="text">{{ $t('message.'+text) }}</p>
        </div>
        <h2>{{$t('message.terminal_tsolution_h2')}}</h2>
        <div class="right-item" v-for="item in items" v-bind:key="item.a">
          <div class="line1">
            <p>{{$t('message.'+item.a)}}</p>
            <p>{{$t('message.'+item.b)}}</p>
          </div>
          <div class="line2" >
            <p v-for="ic in item.c" v-bind:key="ic">{{$t('message.'+ic)}}</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "TSolution",
  data() {
    return {
      texts: [
        'terminal_tsolution_texts_1',
        'terminal_tsolution_texts_2',
        'terminal_tsolution_texts_3',
        'terminal_tsolution_texts_4',
      ],
      items: [
        {
          a: 'terminal_tsolution_items1_a',
          b: 'terminal_tsolution_items1_b',
          c: [
            'terminal_tsolution_items1_c',
          ]
        },
        {
          a: 'terminal_tsolution_items2_a',
          b: 'terminal_tsolution_items2_b',
          c: [
            'terminal_tsolution_items2_c1',
            'terminal_tsolution_items2_c2',
            'terminal_tsolution_items2_c3',
          ]
        },
        {
          a: 'terminal_tsolution_items3_a',
          b: 'terminal_tsolution_items3_b',
          c: [
            'terminal_tsolution_items3_c1',
            'terminal_tsolution_items3_c2',
            'terminal_tsolution_items3_c3',
          ]
        },
        {
          a: 'terminal_tsolution_items4_a',
          b: 'terminal_tsolution_items4_b',
          c: [
            'terminal_tsolution_items4_c1',
            'terminal_tsolution_items4_c2',
            'terminal_tsolution_items4_c3',
            'terminal_tsolution_items4_c4',
          ]
        },
      ],
    }
  },
}
</script>

<style scoped>
#t-solution {
  display: flex;
  flex-direction: column;
  align-items: center;
}

#t-solution .header {
  text-align: center;
  padding: 0 2.27rem 1rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  transform-origin: center;
}

#t-solution .header h1 {
  font-size: var(--40in1980);
  transform-origin: left;
  font-weight: 600;
  color: #2C2C2C;
  margin: 0 0 var(--74in1980);
}

#t-solution .content {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
}

#t-solution .right {
  min-height: var(--650in1980);
  min-width: var(--530in1980);
  display: flex;
  flex-direction: column;
  justify-content: space-around;
}

#t-solution .left {
  //background-color: #6DA656;
  //height: var(--650in1980);
  width: var(--530in1980);
  margin-right: var(--108in1980);
}

#t-solution .left img {
  height: 100%;
  width: 100%;
}

#t-solution .right .right-item{
  //margin: -0.5em 0;
}

#t-solution .right h2 {
  font-size: var(--26in1980);
  font-weight: 600;
  margin-bottom: 0.1em;
}

#t-solution .right p {
  font-size: var(--18in1980);
  margin: 0.1em 0;
}

#t-solution .right .line1>p{
  display: inline;
}

#t-solution .right .line1>p:nth-child(1){
  display: inline-block;
  background-color: #ED4511;
  font-size: var(--14in1980);
  color: white;
  border-radius: 0.2em;
  padding: 0.1em;
  margin: 1em 2em 0.5em 0;
}


#t-solution .right .line1>p:nth-child(1){
  font-weight: 500;
}

</style>
