<template>
  <div id="t-what">
    <div class="t-what-img">
      <img src="../../assets/img/terminal@1x.png" alt="">
    </div>
    <div class="t-what-text">
      <h1>{{$t('message.terminal_that_1')}}</h1>
      <div class="line"></div>
      <p>{{$t('message.terminal_that_2')}}</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "TWhat"
}
</script>

<style scoped>
  #t-what{
    width: 100vw;
    height: 39.44vw;

    background-color: rgba(71, 89, 96, 1);
    position: relative;
    color: #FFFFFF;
  }
  .t-what-img img{
    width: 100%;
  }
  #t-what p{
    margin: 0.5em 0;
  }

  .t-what-text{
    position: absolute;
    top:0;
    bottom: 0;
    left: 41.06vw;
    display: flex;
    flex-direction: column;
    justify-content: center;
    max-height: 100%;

  }

  .t-what-text h1{
    display: flex;
    font-size: var(--40in1980);
    word-wrap: break-word;
    line-height: 1.2em;
  }

  .t-what-text .line{
    display: inline-block;
    width: var(--108in1980);
    height: calc(var(--12in1980)/3);
    margin: 0.5em 0;
    background-color: white;
  }

  .t-what-text p{
    font-size: var(--18in1980);
    max-width: 40em;
    transform-origin: left top;
  }

</style>
