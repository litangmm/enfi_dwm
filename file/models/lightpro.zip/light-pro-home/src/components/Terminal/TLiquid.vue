<template>
  <div id="t-liquid">
    <div id="header">
      <h1>{{$t('message.terminal_tliquid_h1')}}</h1>
      <p>{{$t('message.terminal_tliquid_p')}}</p>
    </div>
    <div id="content">
      <div class="item" v-for="data in datalist" v-bind:key="data.h2">
        <img :src="data.img" alt="">
        <div>
          <h2>{{$t('message.'+data.h2)}}</h2>
          <p class="line"></p>
          <h3>{{$t('message.'+data.h3)}}</h3>
          <p v-for="p in data.ps" :key="p">{{$t('message.'+p)}}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "TLiquid",
  data() {
    return {
      datalist: [
        {
          img: require("../../assets/img/item/item1 (8).png"),
          h2: 'terminal_tliquid_item1_h2',
          h3: 'terminal_tliquid_item1_h3',
          ps: [
            'terminal_tliquid_item1_ps_1',
            'terminal_tliquid_item1_ps_2',
            'terminal_tliquid_item1_ps_3',
            'terminal_tliquid_item1_ps_4',
            'terminal_tliquid_item1_ps_5',
          ]
        },
        {
          img: require("../../assets/img/item/item1 (5).png"),
          h2: 'terminal_tliquid_item2_h2',
          h3: 'terminal_tliquid_item2_h3',
          ps: [
            'terminal_tliquid_item2_ps_1',
            'terminal_tliquid_item2_ps_2',
            'terminal_tliquid_item2_ps_3',
            'terminal_tliquid_item2_ps_4',
            'terminal_tliquid_item2_ps_5',
          ]
        },
        {
          img: require("../../assets/img/item/item1 (2).png"),
          h2: 'terminal_tliquid_item3_h2',
          h3: 'terminal_tliquid_item3_h3',
          ps: [
            'terminal_tliquid_item3_ps_1',
            'terminal_tliquid_item3_ps_2',
            'terminal_tliquid_item3_ps_3',
            'terminal_tliquid_item3_ps_4',
            'terminal_tliquid_item3_ps_5',
          ]
        },
      ]
    }
  },
}
</script>

<style scoped>
#t-liquid {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  margin: 3.95rem;
}

#header {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

#content .item {
  transition: 0.5s;
}

#content {
  display: grid;
  grid-template-columns: repeat(3, 19.19vw);
  grid-template-rows: 24.24vw;
  grid-gap: 4vw 1.51vw;
  overflow: hidden;
}

#content .item {
  color: #FFFFFF;
  display: flex;
  justify-content: center;
  flex-direction: column;
  position: relative;
  background-color: gray;
}

#content .item:hover {
  transform: scale(1.1);
}

#content .item img {
  position: absolute;
  height: 100%;
  width: auto;
}

#content .item:nth-child(1) {
  grid-column: 1/2;
  grid-row: 1/2;
}

#content .item:nth-child(2) {
  grid-column: 2/3;
  grid-row: 1/2;
}

#content .item:nth-child(3) {
  grid-column: 3/4;
  grid-row: 1/2;
}


@media (max-width: 300px) {
  #content {
    display: grid;
    grid-template-columns: 16.31rem;
    grid-template-rows: repeat(3, 9.74rem);
  }

  #content .item {
    overflow: hidden;
  }

  #content .item img {
    position: absolute;
    height: auto;
    width: 100%;
  }

  #content .item:nth-child(1) {
    grid-row: 1/2;
    grid-column: 1/2;
  }

  #content .item:nth-child(2) {
    grid-row: 2/3;
    grid-column: 1/2;
  }

  #content .item:nth-child(3) {
    grid-row: 3/4;
    grid-column: 1/2;
  }
}

/*fs 20*/
#header h1 {
  font-size: var(--40in1980);
  font-weight: 747;
}

/*fs 9*/
#header p {
  font-size: var(--18in1980);
  text-align: center;
  margin: var(--32in1980) 0;
}

/*fs 16*/
#content .item h2 {
  font-size: var(--32in1980);
}

/*fs 10*/
#content .item h3 {
  font-size: var(--22in1980);
}

/*fs 9*/
#content .item p {
  font-size: var(--18in1980);
}

#content .item > div {
  transform: scale(0.8);
}

.line {
  display: inline-block;
  width: var(--82in1980);
  height: calc(var(--12in1980)/3);
  background-color: white;
}
</style>
