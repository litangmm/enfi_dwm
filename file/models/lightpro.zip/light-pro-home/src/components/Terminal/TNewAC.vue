<template>
  <div id="t-what" class="pageMainContainer">
    <div class="top">
      <div class="tag">{{$t('message.terminal_tnewac_1')}}</div>
    </div>
    <div class="icons" >
      <div class="icon" v-for="item of iconList" :key="item.img">
        <i v-bind:class="'iconfont '+ item.img"> </i>
        <p>{{ $t('message.'+item.text) }}</p>
<!--        <span class="tooltiptext">{{ $t('message.'+item.text) }}</span>-->
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "TNewAC",
  data() {
    return {
      iconList: [
        {img: 'icon-shiliangzhinengduixiang1-kaobei_3x', text: 'terminal_tnewac_tag_1'},
        {img: 'icon-shiliangzhinengduixiang2_3x', text: 'terminal_tnewac_tag_2'},
        {img: 'icon-shiliangzhinengduixiang_3x', text: 'terminal_tnewac_tag_3'},
        {img: 'icon-shiliangzhinengduixiang3_3x', text: 'terminal_tnewac_tag_4'},
        {img: 'icon-shiliangzhinengduixiang4_3x', text: 'terminal_tnewac_tag_5'},
        {img: 'icon-shiliangzhinengduixiang5_3x', text: 'terminal_tnewac_tag_6'},
        {img: 'icon-shiliangzhinengduixiang_3x_1_', text: 'terminal_tnewac_tag_7'},
        {img: 'icon-shiliangzhinengduixiang6_3x', text: 'terminal_tnewac_tag_8'},
        {img: 'icon-shiliangzhinengduixiang_3x_2_', text: 'terminal_tnewac_tag_9'},
        {img: 'icon-shiliangzhinengduixiang7_3x', text: 'terminal_tnewac_tag_10'},
      ],
    }
  },

}
</script>

<style scoped>

#t-what{
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: var(--82in1980) 0;
}

#t-what .top .tag{
  font-size: var(--40in1980);
  font-weight: 767;
  color: #2C2C2C;
  margin-bottom: 1em;
}

.icons {
  display: grid;
  grid-template-columns:repeat(5, 1fr);
  grid-template-rows: repeat(2, 1fr);
  grid-gap: var(--88in1980) var(--54in1980);
  font-size: var(--108in1980);
  justify-items: center;
  margin: 1rem auto;
}

.icon p {
  width: 100%;
  text-align: center;
  //white-space: nowrap;
  //overflow: hidden;
  //text-overflow: ellipsis;
  font-size: var(--24in1980);
}

.icon {
  display: flex;
  position: relative;
  justify-content: flex-start;
  align-items: center;
  flex-direction: column;
  max-width: 10vw;
  width: 100%;
  transition: 0.5s;

}

.icons .icon i{
  font-size: var(--108in1980);
}

.icons .icon:hover{
  color: #6DA656;
}
</style>
