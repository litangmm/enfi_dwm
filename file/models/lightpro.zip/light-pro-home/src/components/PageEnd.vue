<template>
  <div id="pageend">
<!--    <canvas id="bottom_Canvas" :width="c_width" :height="c_height" ref="bottom_Canvas"></canvas>-->
    <div class="top pageMainContainer">
      <div class="links">
        <p>{{$t('message.pageend_p1')}}</p>
        <div class="as">
          <a href="https://www.cargill.com.cn/" target="_blank">Cargill</a>
          <a href="https://www.glanbianutritionals.com/zh-hans" target="_blank">Glanbia</a>

          <a href="https://bc30probiotic.com/" target="_blank">GendenBC30</a>
          <a href="https://www.basf.com/cn/zh/industries/lifestyle.html" target="_blank">BASF</a>
          <a href="https://weibo.com/u/7520999653?is_all=1" target="_blank">{{$t('message.pageend_p2')}}</a>
          <a href="https://www.zhihu.com/org/qing-bu-lightpro" target="_blank">{{$t('message.pageend_p3')}}</a>
        </div>
      </div>
      <div class="qrcode">
        <img src="../assets/img/qr.png" alt="">
        <p>{{$t('message.pageend_p4')}}</p>
      </div>
      <div class="tel">
        <p>{{$t('message.pageend_p5')}}</p>
        <p>{{$t('message.pageend_p6')}}</p>
      </div>
    </div>
    <div class="bottom">
      <a href="https://beian.miit.gov.cn/#/Integrated/index" target="_blank">{{$i18n.locale==='zh'?'京ICP备2020032477号':''}}</a>
      <a href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11011102001443" target="_blank">{{$i18n.locale==='zh'?'京公网安备11011102001443':''}}</a>
      <p>Copyright © 2020 LightPro {{$i18n.locale==='zh'?'北京轻补科技有限公司':''}} </p>
    </div>
  </div>
</template>

<script>
export default {
  name: "PageEnd",
  data(){
    return{
      c_width:1980,
      c_height:245,
    }
  },
  // created () {
  //   let canvas = this.$refs.bottom_Canvas;
  //   let windowWidth = window.screen.availWidth;
  //
  //   let [h1, h2] = [213/1980*windowWidth, 245/1980*windowWidth];
  //   let triangle = 160/1980*windowWidth;
  //   let [w1, w2] = [990/1980*windowWidth, 1980/1980*windowWidth];
  //
  //   this.c_width = windowWidth;
  //   this.c_height = h2;
  //
  //   let ctx = canvas.getContext('2d');
  //   ctx.fillStyle = 'RGBA(69, 82, 91, 1)';
  //   ctx.fillRect(0, h2 - h1, w2, h1);
  //
  //   ctx.fillStyle = 'RGBA(51, 59, 65, 1)';
  //   ctx.beginPath();
  //   let dots = [
  //     { x: w1 + triangle, y: 0 },
  //     { x: w2, y: 0 },
  //     { x: w2, y: h2 },
  //     { x: 0, y: h2 },
  //     { x: 0, y: h1 - (h2 - triangle) },
  //     { x: w1, y: h1 - (h2 - triangle) },
  //     { x: w1 + triangle, y: 0 },
  //   ]
  //   ctx.moveTo(dots[0].x, dots[0].y)
  //   dots.forEach(({ x, y }) => {
  //     ctx.lineTo(x, y)
  //     console.log(x, y)
  //   })
  //   ctx.fill();
  // },
}
</script>

<style scoped>
  #pageend{
    background: RGBA(69, 82, 91, 1);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 1em 0;
    //height: var(--214in1980);
    position: relative;
  }
  #pageend #bottom_Canvas{
    position: absolute;
    z-index: -1;
  }
  #pageend *{
    color: #FFFFFF;
  }

  #pageend a:hover{
    color: #6DA656;
  }

  .top{
    display: flex;
    flex-wrap: wrap;
    align-items: center;
  }

  .links{
    flex: 1;
  }

  .links>p{
    display: inline-block;
    padding-bottom: calc(var(--12in1980)/4);
    border-bottom: calc(var(--12in1980)/4) #ffffff solid ;
    margin:0 var(--32in1980) 1rem;
  }

  .links div>a{
    padding:0 var(--32in1980);
    border-right: 1px #FFFFFF solid ;
    font-size: var(--16in1980);
  }

  .links div>a:last-child{
    border-right: none;
  }

  .qrcode{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }

  .qrcode img{
    width: var(--88in1980);
  }

  .qrcode p{
    font-size: var(--12in1980);
    margin-top: 0.5em;
  }

  .tel{
    margin-left: 2em ;
  }
  .tel p{
    font-size: var(--16in1980);
    margin: 1em 0;
  }

  .bottom a{
    margin: 0 calc(var(--12in1980)/2);
  }

  .bottom p{
    display: inline-block;
    margin: 0 calc(var(--12in1980)/2);
  }

  .bottom{
    font-size: var(--14in1980);
    margin-top: var(--12in1980);;
  }

</style>
