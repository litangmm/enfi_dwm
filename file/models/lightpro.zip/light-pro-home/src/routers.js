import HomePage from "@/pages/HomePage";
import MiniMeal from "@/pages/MiniMeal";
import Terminal from "@/pages/Terminal";
import Story from "@/pages/Story";
import page404 from '@/pages/404'

const SAdvocate =  () => import(/* webpackChunkName: 'Story' */ '@/components/Story/SAdvocate')
const SConcept =  () => import(/* webpackChunkName: 'Story' */ '@/components/Story/SConcept')
const SContact =  () => import(/* webpackChunkName: 'Story' */ '@/components/Story/SContact')
const SDesc =  () => import(/* webpackChunkName: 'Story' */ '@/components/Story/SDesc')
const SJoin =  () => import(/* webpackChunkName: 'Story' */ '@/components/Story/SJoin')

const routers = [
    {
        path: '/',
        component: HomePage,
    },
    {
        path: '/homepage',
        redirect: '/',
    },
    {
        name: 'minimeal',
        path: '/minimeal',
        component: MiniMeal,
    },
    {
        name: 'terminal',
        path: '/terminal',
        component: Terminal,
    },
    {
        name: 'story',
        path: '/story',
        component: Story,
        children: [
            {
                path: '',
                redirect: 'concept',
            },
            {
                path: 'advocate',
                component: SAdvocate,
            },
            {
                path: 'contact',
                component: SContact,
            },
            {
                path: 'desc',
                component: SDesc,
            },
            {
                path: 'concept',
                component: SConcept,
            },
            {
                path: 'join',
                component: SJoin,
            },
        ],
    },
    {
        path: '/404',
        component: page404,
    },
    {
        path: '*',    // 此处需特别注意至于最底部
        component: page404,
    },

]

export default routers
