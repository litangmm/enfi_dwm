<template>
  <div id="app">
    <TabBar></TabBar>
    <router-view></router-view>
  </div>
</template>

<script>
import TabBar from "@/components/TabBar";
// import PageEnd from "@/components/PageEnd";
import './init.css'

export default {
  name: 'App',
  components: {
    TabBar,
  },
  head: {
    title: '轻补科技(LightPro)-植物基运动营养|保健营养',
    titleTemplate() {
      return this.$i18n.locale === 'en'?'LightPro: Plant-Based Sports Nutrition':'轻补科技(LightPro)-植物基运动营养'
    },
  },
  created() {

  }
}
</script>

<style>
:root {
  font-size: calc(1vw + 0.6em);
  --size-20-ns: 1.03rem;
  --size-16-ns: 0.82rem;
  --size-12-ns: 0.62rem;
  --size-20: 1.28rem;
  --size-13: 0.83rem;
  --size-10: 0.64rem;
  --size-9: 0.58rem;
  --trans-scale: 0.8;
}
@media (min-width: 200px) {
  :root{
    font-size: 1vw;
    --design-rem: 19.8;
    --1358in1980: calc(1358/var(--design-rem)*1rem);
    --1034in1980: calc(1034/var(--design-rem)*1rem);
    --840in1980: calc(840/var(--design-rem)*1rem);
    --770in1980: calc(770/var(--design-rem)*1rem);
    --650in1980: calc(650/var(--design-rem)*1rem);
    --624in1980: calc(624/var(--design-rem)*1rem);
    --534in1980: calc(534/var(--design-rem)*1rem);
    --530in1980: calc(530/var(--design-rem)*1rem);
    --494in1980: calc(494/var(--design-rem)*1rem);
    --474in1980: calc(474/var(--design-rem)*1rem);
    --410in1980: calc(410/var(--design-rem)*1rem);
    --400in1980: calc(400/var(--design-rem)*1rem);
    --214in1980: calc(214/var(--design-rem)*1rem);
    --195in1980: calc(195/var(--design-rem)*1rem);
    --148in1980: calc(148/var(--design-rem)*1rem);
    --138in1980: calc(138/var(--design-rem)*1rem);
    --124in1980: calc(124/var(--design-rem)*1rem);
    --112in1980: calc(112/var(--design-rem)*1rem);
    --108in1980: calc(108/var(--design-rem)*1rem);
    --88in1980: calc(88/var(--design-rem)*1rem);
    --82in1980: calc(82/var(--design-rem)*1rem);
    --74in1980: calc(74/var(--design-rem)*1rem);
    --60in1980: calc(60/var(--design-rem)*1rem);
    --58in1980: calc(58/var(--design-rem)*1rem);
    --54in1980: calc(54/var(--design-rem)*1rem);
    --50in1980: calc(50/var(--design-rem)*1rem);
    --46in1980: calc(46/var(--design-rem)*1rem);
    --40in1980: calc(40/var(--design-rem)*1rem);
    --36in1980: calc(36/var(--design-rem)*1rem);
    --32in1980: calc(32/var(--design-rem)*1rem);
    --28in1980: calc(28/var(--design-rem)*1rem);
    --26in1980: calc(26/var(--design-rem)*1rem);
    --24in1980: calc(24/var(--design-rem)*1rem);
    --22in1980: calc(22/var(--design-rem)*1rem);
    --20in1980: calc(20/var(--design-rem)*1rem);
    --18in1980: calc(18/var(--design-rem)*1rem);
    --16in1980: calc(16/var(--design-rem)*1rem);
    --14in1980: calc(14/var(--design-rem)*1rem);
    --12in1980: calc(12/var(--design-rem)*1rem);
    --10in1980: calc(10/var(--design-rem)*1rem);
  }
}
#app {
  //margin: 3em auto auto;
  font-family: SourceHanSansCN-Regular,Arial,sans-serif;
  overflow: hidden;
  margin: auto;
}

.pageFlexColumnContainer{
  display: flex;
  flex-direction: column;
  width: 100vw;
  //min-width: 1000px;
}

.pageMainContainer{
  width: 62.5vw;
  //min-width: 625px;
  margin: auto;
}

</style>
